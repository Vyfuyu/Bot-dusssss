# main.py
from dotenv import load_dotenv # Dòng này được thêm vào
load_dotenv() # Dòng này được thêm vào

import discord
from discord.ext import commands
import os
import asyncio
from keep_alive import keep_alive
import logging # Thư viện ghi log

# --- CẤU HÌNH LOGGING CHUYÊN NGHIỆP ---
# Cấu hình để log sẽ ghi ra cả Console và file bot.log
logger = logging.getLogger('discord')
logger.setLevel(logging.INFO) # Ghi lại các thông tin từ mức INFO trở lên
handler = logging.FileHandler(filename='bot.log', encoding='utf-8', mode='w')
handler.setFormatter(logging.Formatter('%(asctime)s:%(levelname)s:%(name)s: %(message)s'))
logger.addHandler(handler)

# --- CÀI ĐẶT CƠ BẢN CỦA BOT ---
TOKEN = os.environ['DISCORD_TOKEN']
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix='!', intents=intents)

# --- SỰ KIỆN KHI BOT SẴN SÀNG ---
@bot.event
async def on_ready():
    # Thay print bằng logging.info
    logging.info(f'Đăng nhập thành công với tên {bot.user.name} (ID: {bot.user.id})')
    logging.info('---------------------------------')
    await bot.change_presence(activity=discord.Game(name="!help để xem lệnh"))

# --- HÀM TẢI COGS ---
async def load_cogs():
    for filename in os.listdir('./cogs'):
        if filename.endswith('.py'):
            try:
                await bot.load_extension(f'cogs.{filename[:-3]}')
                # Thay print bằng logging.info
                logging.info(f'✅ Đã tải thành công cog: {filename}')
            except Exception as e:
                # Thay print bằng logging.error
                logging.error(f'❌ Lỗi khi tải cog {filename}: {e}', exc_info=True)

# --- HÀM CHÍNH ĐỂ CHẠY BOT ---
async def main():
    await load_cogs()
    keep_alive()
    await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())