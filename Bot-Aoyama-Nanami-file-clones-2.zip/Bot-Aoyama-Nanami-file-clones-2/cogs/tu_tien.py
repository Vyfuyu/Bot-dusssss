# cogs/tu_tien.py

import discord
from discord.ext import commands
import json
import os
import random
from datetime import datetime, timedelta
import math

# --- CẤU HÌNH TRÒ CHƠI TU TIÊN ---
DATA_FOLDER = "data"
USER_DATA_FILE = os.path.join(DATA_FOLDER, "tu_tien_data.json")

# Lượng EXP nhận được mỗi lần và thời gian chờ
EXP_GAIN_MIN = 15
EXP_GAIN_MAX = 30
EXP_COOLDOWN_SECONDS = 60 # 60 giây

# Các cảnh giới tu tiên và cấp độ yêu cầu để đột phá
REALMS = [
    ("Luyện Khí", 0),
    ("Trúc Cơ", 10),
    ("Kim Đan", 30),
    ("Nguyên Anh", 50),
    ("Hóa Thần", 80),
    ("Luyện Hư", 120),
    ("Hợp Thể", 150),
    ("Đại Thừa", 200),
    ("Độ Kiếp", 250),
    ("Tiên Nhân", 300)
]

class TuTien(commands.Cog):
    """Hệ thống tu tiên ngay trên Discord!"""
    def __init__(self, bot):
        self.bot = bot
        self.user_data = self.load_user_data()

    # --- HÀM QUẢN LÝ DỮ LIỆU ---
    def load_user_data(self):
        if not os.path.exists(DATA_FOLDER):
            os.makedirs(DATA_FOLDER)
        if not os.path.exists(USER_DATA_FILE):
            return {}
        try:
            with open(USER_DATA_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {}

    def save_user_data(self):
        with open(USER_DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.user_data, f, indent=4, ensure_ascii=False)

    def get_exp_for_level(self, level):
        """Công thức tính EXP cần để lên cấp."""
        return math.floor(100 * (level ** 1.5))

    def get_user_entry(self, user_id):
        user_id_str = str(user_id)
        if user_id_str not in self.user_data:
            self.user_data[user_id_str] = {
                "level": 1,
                "exp": 0,
                "realm_index": 0, # Index của cảnh giới trong list REALMS
                "last_exp_gain": None
            }
        return self.user_data[user_id_str]

    # --- HỆ THỐNG CỐT LÕI (Lắng nghe tin nhắn) ---
    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or message.content.startswith(self.bot.command_prefix):
            return # Bỏ qua tin nhắn từ bot và các lệnh

        user_id = message.author.id
        user_entry = self.get_user_entry(user_id)

        # Kiểm tra thời gian chờ
        now = datetime.now()
        if user_entry["last_exp_gain"]:
            last_gain_time = datetime.fromisoformat(user_entry["last_exp_gain"])
            if now < last_gain_time + timedelta(seconds=EXP_COOLDOWN_SECONDS):
                return # Vẫn trong thời gian chờ

        # Cộng EXP
        exp_gained = random.randint(EXP_GAIN_MIN, EXP_GAIN_MAX)
        user_entry["exp"] += exp_gained
        user_entry["last_exp_gain"] = now.isoformat()

        # Kiểm tra lên cấp
        exp_needed = self.get_exp_for_level(user_entry["level"])
        leveled_up = False
        while user_entry["exp"] >= exp_needed:
            user_entry["level"] += 1
            user_entry["exp"] -= exp_needed
            leveled_up = True
            exp_needed = self.get_exp_for_level(user_entry["level"])

        self.save_user_data()

        # Nếu lên cấp, gửi thông báo
        if leveled_up:
            realm_name, _ = REALMS[user_entry["realm_index"]]
            level_up_embed = discord.Embed(
                title="✨ Chúc Mừng Lên Cấp! ✨",
                description=f"Chúc mừng **{message.author.mention}** đã khổ luyện thành công, đạt đến **cấp {user_entry['level']}** của cảnh giới **{realm_name}**!",
                color=discord.Color.gold()
            )
            await message.channel.send(embed=level_up_embed)

    # --- CÁC LỆNH CHO NGƯỜI DÙNG ---
    @commands.command(name="tuvi", aliases=['tt', 'info'], help="Kiểm tra thông tin tu vi của bạn.")
    async def tuvi(self, ctx, member: discord.Member = None):
        target_user = member or ctx.author
        user_entry = self.get_user_entry(target_user.id)

        level = user_entry['level']
        exp = user_entry['exp']
        realm_index = user_entry['realm_index']
        realm_name, _ = REALMS[realm_index]
        exp_needed = self.get_exp_for_level(level)

        embed = discord.Embed(
            title=f"📜 Tu Vi của {target_user.display_name}",
            color=discord.Color.from_rgb(128, 0, 128) # Màu tím huyền bí
        )
        embed.set_thumbnail(url=target_user.display_avatar.url)
        embed.add_field(name="Cảnh Giới", value=f"**{realm_name}**", inline=True)
        embed.add_field(name="Cấp Độ", value=f"**{level}**", inline=True)
        embed.add_field(name="Kinh Nghiệm (EXP)", value=f"`{exp} / {exp_needed}`", inline=False)

        # Hiển thị thông tin đột phá
        if realm_index + 1 < len(REALMS):
            next_realm_name, level_req = REALMS[realm_index + 1]
            if level >= level_req:
                embed.add_field(name="Đột Phá", value=f"Đã đủ điều kiện! Dùng `!độtphá` để tiến lên **{next_realm_name}**.", inline=False)
            else:
                embed.add_field(name="Đột Phá", value=f"Cần đạt **cấp {level_req}** để đột phá lên **{next_realm_name}**.", inline=False)
        else:
            embed.add_field(name="Đột Phá", value="Bạn đã đạt đến cảnh giới tối thượng!", inline=False)

        await ctx.send(embed=embed)

    @commands.command(name="độtphá", aliases=['dp', 'breakthrough'], help="Vận công đột phá cảnh giới mới!")
    async def breakthrough(self, ctx):
        user_entry = self.get_user_entry(ctx.author.id)
        current_realm_index = user_entry['realm_index']

        if current_realm_index + 1 >= len(REALMS):
            return await ctx.send("☯️ **{ctx.author.display_name}**, ngươi đã là đỉnh cao của vũ trụ này, không thể đột phá thêm nữa!")

        next_realm_name, level_req = REALMS[current_realm_index + 1]
        if user_entry['level'] < level_req:
            return await ctx.send(f"❌ **{ctx.author.display_name}**, công lực chưa đủ, cần đạt **cấp {level_req}** mới có thể đột phá!")

        # Thực hiện đột phá
        user_entry['realm_index'] += 1
        self.save_user_data()

        announcement_embed = discord.Embed(
            title="⚡️ THIÊN ĐỊA BIẾN SẮC - ĐỘT PHÁ THÀNH CÔNG ⚡️",
            description=f"Trời đất rung chuyển, linh khí hội tụ! Chúc mừng đạo hữu **{ctx.author.mention}** đã vượt qua tâm ma, thành công đột phá, chính thức bước vào **{next_realm_name}** cảnh!",
            color=discord.Color.red()
        )
        announcement_embed.set_thumbnail(url="https://i.imgur.com/8QpF5mN.gif") # Ảnh gif sấm sét

        await ctx.send(embed=announcement_embed)

    @commands.command(name="bảngxếphạng", aliases=['bxh', 'top'], help="Xem bảng xếp hạng các cao thủ tu tiên.")
    async def leaderboard(self, ctx):
        if not self.user_data:
            return await ctx.send("Chưa có ai bắt đầu con đường tu tiên.")

        # Sắp xếp người dùng: ưu tiên cảnh giới > cấp độ > exp
        sorted_users = sorted(
            self.user_data.items(),
            key=lambda item: (item[1]['realm_index'], item[1]['level'], item[1]['exp']),
            reverse=True
        )

        embed = discord.Embed(title="🏆 Bảng Xếp Hạng Tu Tiên Giả 🏆", color=discord.Color.blue())

        for i, (user_id, data) in enumerate(sorted_users[:10]): # Lấy top 10
            try:
                member = await ctx.guild.fetch_member(int(user_id))
                member_name = member.display_name
            except (discord.NotFound, ValueError):
                member_name = f"Người dùng {user_id[-4:]}" # Hiển thị 4 số cuối ID nếu không tìm thấy user

            rank = i + 1
            realm_name, _ = REALMS[data['realm_index']]
            level = data['level']
            embed.add_field(name=f"#{rank} {member_name}", value=f"**{realm_name}** - Cấp **{level}**", inline=False)

        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(TuTien(bot))