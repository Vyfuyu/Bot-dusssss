# cogs/server_setup.py (Phiên bản SIÊU NÂNG CẤP với quyền hạn tự động)

import discord
from discord.ext import commands
import asyncio

# --- KHO LƯU TRỮ CÁC MẪU SERVER NÂNG CAO ---
# Giờ đây, mỗi kênh sẽ có thêm mục 'permissions'
# role_name: Tên role cần xét quyền. Dùng "@everyone" cho tất cả mọi người.
# allow/deny: Danh sách các quyền muốn Bật/Tắt. Tên quyền phải đúng theo tên của discord.py
# Ví dụ: send_messages, add_reactions, read_messages, connect, speak...
SERVER_TEMPLATES = {
    "gaming": {
        "description": "🎮 Mẫu server tối ưu cho cộng đồng Game thủ, với các phòng game và voice chat.",
        "roles": ["👑 Owner", "🛡️ Quản Trị Viên", "⚔️ Moderator", "💎 Booster", "🎮 Gamer", "✅ Member", "🤖 Bots"],
        "categories": [
            {"name": "🔒 ADMIN ONLY", "permissions": [{"role_name": "@everyone", "deny": ["read_messages"]}, {"role_name": "Quản Trị Viên", "allow": ["read_messages"]}, {"role_name": "Moderator", "allow": ["read_messages"]}], "channels": [
                {"name": "🔒-admin-chat", "type": "text"},
                {"name": "🔒-logs", "type": "text"},
            ]},
            {"name": "🎮 WELCOME & INFO", "channels": [
                {"name": "👋-welcome", "type": "text", "permissions": [{"role_name": "@everyone", "deny": ["send_messages", "add_reactions"]}]},
                {"name": "📜-rules", "type": "text", "permissions": [{"role_name": "@everyone", "deny": ["send_messages"]}]},
                {"name": "📢-announcements", "type": "text", "permissions": [{"role_name": "@everyone", "deny": ["send_messages"]}]},
                {"name": "🎁-giveaways", "type": "text", "permissions": [{"role_name": "@everyone", "deny": ["send_messages"]}]},
                {"name": "✨-lấy-vai-trò", "type": "text"}
            ]},
            {"name": "💬 KHU VỰC CHUNG", "channels": [
                {"name": "💬-chat-chung", "type": "text"},
                {"name": "😂-memes", "type": "text"},
                {"name": "🤖-bot-commands", "type": "text"}
            ]},
            {"name": "⚔️ PHÒNG GAME", "channels": [
                {"name": "Tìm đồng đội", "type": "text"},
                {"name": "Valorant", "type": "voice"},
                {"name": "Genshin Impact", "type": "voice"},
                {"name": "CSGO / CS2", "type": "voice"},
                {"name": "Treo Sảnh", "type": "voice"},
                {"name": "💤 AFK", "type": "voice", "permissions": [{"role_name": "@everyone", "deny": ["speak"]}]}
            ]}
        ]
    },
    "social": {
        "description": "☕ Mẫu server tối ưu cho cộng đồng Giao lưu, Kết bạn và Trò chuyện.",
        "roles": ["👑 Founder", "🛡️ Admin", "💬 Host", "✨ Active Member", "✅ Member", "🤖 Bots"],
        "categories": [
            {"name": "☕ WELCOME", "channels": [
                {"name": "👋-chào-mừng", "type": "text", "permissions": [{"role_name": "@everyone", "deny": ["send_messages"]}]},
                {"name": "📜-nội-quy", "type": "text", "permissions": [{"role_name": "@everyone", "deny": ["send_messages"]}]},
                {"name": "📢-thông-báo", "type": "text", "permissions": [{"role_name": "@everyone", "deny": ["send_messages"]}]}
            ]},
            {"name": "💬 PHÒNG TRÒ CHUYỆN", "channels": [
                {"name": "💬-tán-gẫu", "type": "text"},
                {"name": "💖-tâm-sự", "type": "text"},
                {"name": "😂-góc-giải-trí", "type": "text"},
                {"name": "🎵-âm-nhạc", "type": "text"},
                {"name": "🎬-phim-ảnh", "type": "text"},
                {"name": "🤖-lệnh-bot", "type": "text"}
            ]},
            {"name": "🎧 KÊNH THOẠI", "channels": [
                {"name": "Tâm sự đêm khuya", "type": "voice"},
                {"name": "Nghe nhạc cùng nhau", "type": "voice"},
                {"name": "Phòng chờ", "type": "voice"},
                {"name": "💤 AFK", "type": "voice", "permissions": [{"role_name": "@everyone", "deny": ["speak"]}]}
            ]}
        ]
    },
    # Bạn có thể thêm các mẫu "study" và "cool" vào đây với cấu trúc tương tự nếu muốn
}

CONFIRMATION_PHRASE_PREFIX = "AOYAMA_SETUP_EXECUTE"

class ServerSetup(commands.Cog):
    """Lệnh tự động thiết lập một server Discord mới với nhiều mẫu và quyền hạn chi tiết."""
    def __init__(self, bot):
        self.bot = bot

    async def create_roles(self, guild, roles_to_create):
        created_roles = {}
        for role_name in reversed(roles_to_create):
            if not discord.utils.get(guild.roles, name=role_name):
                new_role = await guild.create_role(name=role_name, reason="Auto setup by Aoyama Bot")
                created_roles[role_name] = new_role
                await asyncio.sleep(0.5)
            else:
                created_roles[role_name] = discord.utils.get(guild.roles, name=role_name)
        return created_roles

    async def create_channels(self, guild, categories_to_create, created_roles):
        for category_data in categories_to_create:
            category_name = category_data["name"]
            category_perms_rules = category_data.get("permissions", [])

            category_overwrites = {}
            for perm_rule in category_perms_rules:
                role_name = perm_rule["role_name"]
                role = created_roles.get(role_name) or (guild.default_role if role_name == "@everyone" else None)
                if role:
                    perms = discord.PermissionOverwrite()
                    for allow_perm in perm_rule.get("allow", []): setattr(perms, allow_perm, True)
                    for deny_perm in perm_rule.get("deny", []): setattr(perms, deny_perm, False)
                    category_overwrites[role] = perms

            new_category = await guild.create_category(name=category_name, overwrites=category_overwrites)
            await asyncio.sleep(0.5)

            for channel_data in category_data.get("channels", []):
                channel_name, channel_type = channel_data["name"], channel_data["type"]
                channel_perms_rules = channel_data.get("permissions", [])

                channel_overwrites = {}
                for perm_rule in channel_perms_rules:
                    role_name = perm_rule["role_name"]
                    role = created_roles.get(role_name) or (guild.default_role if role_name == "@everyone" else None)
                    if role:
                        perms = discord.PermissionOverwrite()
                        for allow_perm in perm_rule.get("allow", []): setattr(perms, allow_perm, True)
                        for deny_perm in perm_rule.get("deny", []): setattr(perms, deny_perm, False)
                        channel_overwrites[role] = perms

                if channel_type == "text":
                    await guild.create_text_channel(name=channel_name, category=new_category, overwrites=channel_overwrites)
                elif channel_type == "voice":
                    await guild.create_voice_channel(name=channel_name, category=new_category, overwrites=channel_overwrites)
                await asyncio.sleep(0.5)

    @commands.group(name="setup", invoke_without_command=True, help="[ADMIN] Hệ thống thiết lập server tự động.")
    @commands.has_permissions(administrator=True)
    async def setup(self, ctx):
        embed = discord.Embed(title="Hệ thống Thiết lập Server Tự động", description="Sử dụng các lệnh con để tạo hoặc dọn dẹp server.", color=discord.Color.blue())
        template_list = "\n".join([f"**- `{name}`**: {data['description']}" for name, data in SERVER_TEMPLATES.items()])
        embed.add_field(name="Các mẫu có sẵn:", value=template_list, inline=False)
        embed.add_field(name="Lệnh tạo:", value="`!setup create <tên_mẫu>`", inline=False)
        embed.add_field(name="Lệnh dọn dẹp:", value="`!setup clean`", inline=False)
        await ctx.send(embed=embed)

    @setup.command(name="create", help="Tạo server theo một mẫu có sẵn.")
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True, manage_roles=True)
    async def setup_create(self, ctx, template_name: str = None, *, confirmation: str = None):
        if not template_name or template_name.lower() not in SERVER_TEMPLATES:
            return await ctx.send(f"❌ Tên mẫu không hợp lệ. Các mẫu có sẵn: `{', '.join(SERVER_TEMPLATES.keys())}`")

        template = SERVER_TEMPLATES[template_name.lower()]
        CONFIRMATION_PHRASE = f"{CONFIRMATION_PHRASE_PREFIX}-{template_name.upper()}"

        if confirmation != CONFIRMATION_PHRASE:
            embed = discord.Embed(title=f"⚠️ Xác nhận Thiết lập theo mẫu '{template_name}'", description=template.get("description"), color=discord.Color.orange())
            embed.add_field(name="Để xác nhận, hãy chạy lại lệnh với mã sau:", value=f"```!setup create {template_name} {CONFIRMATION_PHRASE}```")
            return await ctx.send(embed=embed)

        await ctx.send(f"✅ **Đã xác nhận!** Bắt đầu thiết lập server... Quá trình này sẽ mất vài phút.")
        try:
            await ctx.send("🔄 **Bước 1/2: Đang tạo Vai trò...**")
            created_roles = await self.create_roles(ctx.guild, template["roles"])

            await ctx.send("🔄 **Bước 2/2: Đang tạo Kênh và thiết lập Quyền hạn...**")
            await self.create_channels(ctx.guild, template["categories"], created_roles)

            await ctx.send(embed=discord.Embed(title="🎉 Thiết lập Server Hoàn tất!", color=discord.Color.green()))
        except discord.Forbidden: await ctx.send("❌ **Lỗi quyền hạn!** Hãy đảm bảo vai trò của bot ở vị trí cao và có đủ quyền.")
        except Exception as e: await ctx.send(f"❌ Đã có lỗi không mong muốn xảy ra: {e}")

    @setup.command(name="clean", help="Xóa TOÀN BỘ kênh và vai trò.")
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True, manage_roles=True)
    async def setup_clean(self, ctx, *, confirmation: str = None):
        CONFIRMATION_PHRASE = f"{ctx.guild.name.upper().replace(' ', '_')}-NUKE"
        if confirmation != CONFIRMATION_PHRASE:
            embed = discord.Embed(title="🚨 CẢNH BÁO CỰC KỲ NGUY HIỂM 🚨", description="Lệnh này sẽ **XÓA SẠCH** tất cả các kênh và vai trò hiện có. **KHÔNG THỂ HOÀN TÁC.**", color=discord.Color.dark_red())
            embed.add_field(name="Để xác nhận, hãy chạy lại lệnh với mã sau:", value=f"```!setup clean {CONFIRMATION_PHRASE}```")
            return await ctx.send(embed=embed)

        await ctx.send("✅ **Đã xác nhận!** Bắt đầu quá trình dọn dẹp server... Thao tác này sẽ mất nhiều thời gian.")
        for channel in ctx.guild.channels:
            try: await channel.delete(reason="Server Cleanup"); await asyncio.sleep(1)
            except: pass
        for role in ctx.guild.roles:
            if role.is_default() or role.is_integration() or role.is_premium_subscriber() or role.managed: continue
            try: await role.delete(reason="Server Cleanup"); await asyncio.sleep(1)
            except: pass
        await ctx.send("🔥 **Dọn dẹp hoàn tất!**")

async def setup(bot):
    await bot.add_cog(ServerSetup(bot))