# cogs/admin.py (Phiên bản ổn định, chuyên về quản lý quyền và công cụ)

import discord
from discord.ext import commands
import json
import os
import secrets
from datetime import datetime, timedelta

# --- CẤU HÌNH ---
DATA_FOLDER = "data"
PERMISSIONS_FILE = os.path.join(DATA_FOLDER, "permissions_data.json")

# --- CÁC HÀM KIỂM TRA QUYỀN HẠN (ĐỂ CÁC COG KHÁC IMPORT) ---
def get_permissions_data():
    if not os.path.exists(PERMISSIONS_FILE): return {}
    with open(PERMISSIONS_FILE, 'r', encoding='utf-8') as f:
        try: return json.load(f)
        except json.JSONDecodeError: return {}

def is_bot_support():
    async def predicate(ctx):
        if await ctx.bot.is_owner(ctx.author): return True
        data = get_permissions_data()
        admin_list = data.get("bot_admins", [])
        support_list = data.get("bot_support", [])
        return ctx.author.id in admin_list or ctx.author.id in support_list
    return commands.check(predicate)

def is_bot_admin():
    async def predicate(ctx):
        if await ctx.bot.is_owner(ctx.author): return True
        data = get_permissions_data()
        admin_list = data.get("bot_admins", [])
        return ctx.author.id in admin_list
    return commands.check(predicate)

# --- CÁC VIEW CHO GIAO DIỆN NÚT BẤM ---
class LogPaginatorView(discord.ui.View):
    def __init__(self, author: discord.User, pages: list):
        super().__init__(timeout=300); self.author, self.pages, self.current_page = author, pages, 0; self.update_buttons()
    async def interaction_check(self, i: discord.Interaction) -> bool:
        if i.user != self.author: await i.response.send_message("Đây không phải menu của bạn!", ephemeral=True); return False
        return True
    def create_embed(self):
        return discord.Embed(title=f"📝 Log Console (Trang {self.current_page + 1}/{len(self.pages)})", description=f"```log\n{self.pages[self.current_page]}\n```", color=discord.Color.dark_grey())
    def update_buttons(self):
        self.children[0].disabled = self.current_page == 0; self.children[1].disabled = self.current_page >= len(self.pages) - 1
    @discord.ui.button(label="⬅️ Trước", style=discord.ButtonStyle.secondary)
    async def prev(self, i: discord.Interaction, b: discord.ui.Button): self.current_page -= 1; self.update_buttons(); await i.response.edit_message(embed=self.create_embed(), view=self)
    @discord.ui.button(label="Sau ➡️", style=discord.ButtonStyle.primary)
    async def next(self, i: discord.Interaction, b: discord.ui.Button): self.current_page += 1; self.update_buttons(); await i.response.edit_message(embed=self.create_embed(), view=self)

class GuildPaginatorView(discord.ui.View):
    def __init__(self, author: discord.User, bot_ref, guilds: list, per_page: int = 5):
        super().__init__(timeout=300)
        self.author, self.bot, self.guilds, self.per_page = author, bot_ref, guilds, per_page
        self.current_page = 0; self.total_pages = (len(guilds) - 1) // per_page + 1
        self.update_buttons()
    async def interaction_check(self, i: discord.Interaction) -> bool:
        if i.user.id != self.author.id: await i.response.send_message("Đây không phải menu của bạn!", ephemeral=True); return False
        return True
    def create_embed(self):
        start_index = self.current_page * self.per_page; guilds_on_page = self.guilds[start_index : start_index + self.per_page]
        embed = discord.Embed(title="📊 Thống kê Server của Bot 📊", description=f"Bot đang ở trong tổng cộng **{len(self.guilds)}** server.", color=discord.Color.teal())
        for guild in guilds_on_page:
            bot_member = guild.me
            roles = [role.name for role in bot_member.roles if not role.is_default()]
            roles_str = ", ".join(roles) if roles else "Không có vai trò đặc biệt"
            field_value = f"**ID:** `{guild.id}`\n**Thành viên:** {guild.member_count}\n**Vai trò của Bot:** `{roles_str}`"
            embed.add_field(name=f"📄 {guild.name}", value=field_value, inline=False)
        embed.set_footer(text=f"Trang {self.current_page + 1}/{self.total_pages}")
        return embed
    def update_buttons(self):
        self.children[0].disabled = self.current_page == 0; self.children[1].disabled = self.current_page >= self.total_pages - 1
    @discord.ui.button(label="⬅️ Trước", style=discord.ButtonStyle.secondary)
    async def prev(self, i: discord.Interaction, b: discord.ui.Button): self.current_page -= 1; self.update_buttons(); await i.response.edit_message(embed=self.create_embed(), view=self)
    @discord.ui.button(label="Sau ➡️", style=discord.ButtonStyle.primary)
    async def next(self, i: discord.Interaction, b: discord.ui.Button): self.current_page += 1; self.update_buttons(); await i.response.edit_message(embed=self.create_embed(), view=self)


class Admin(commands.Cog):
    """Quản lý quyền hạn và các lệnh admin cấp cao của bot."""
    def __init__(self, bot):
        self.bot = bot
        self.permissions_data = self.load_permissions_data()

    def load_permissions_data(self):
        if not os.path.exists(DATA_FOLDER): os.makedirs(DATA_FOLDER)
        if not os.path.exists(PERMISSIONS_FILE):
            initial_data = {"bot_admins": [], "bot_support": [], "pending_requests": {}}
            with open(PERMISSIONS_FILE, 'w') as f: json.dump(initial_data, f, indent=4)
            return initial_data
        with open(PERMISSIONS_FILE, 'r', encoding='utf-8') as f:
            try: return json.load(f)
            except json.JSONDecodeError: return {"bot_admins": [], "bot_support": [], "pending_requests": {}}

    def save_permissions_data(self):
        with open(PERMISSIONS_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.permissions_data, f, indent=4)

    @commands.command(name="checkconsole", help="[ADMIN] Xem log của bot.")
    @is_bot_admin()
    async def check_console(self, ctx):
        if not os.path.exists('bot.log'): return await ctx.send("❌ Không tìm thấy file log.")
        with open('bot.log', 'r', encoding='utf-8') as f: full_log_content = f.read()
        if not full_log_content.strip(): return await ctx.send("File log trống.")
        pages = [full_log_content[i:i+1900] for i in range(0, len(full_log_content), 1900)]
        try:
            view = LogPaginatorView(ctx.author, pages)
            await ctx.author.send(embed=view.create_embed(), view=view)
            await ctx.send("✅ Đã gửi bảng điều khiển log vào tin nhắn riêng của bạn!")
        except discord.Forbidden: await ctx.send("❌ Không thể gửi tin nhắn riêng cho bạn.")

    @commands.command(name="adminmenu", aliases=['amenu'], help="[ADMIN] Hiển thị menu các lệnh quản trị.")
    @is_bot_admin()
    async def admin_menu(self, ctx):
        embed = discord.Embed(title="⚙️ Bảng Điều Khiển Admin ⚙️", description="Tổng hợp các lệnh có quyền hạn cao của bot.", color=discord.Color.dark_red())
        admin_commands_by_cog = {}
        for cog_name, cog in self.bot.cogs.items():
            cog_admin_commands = [cmd for cmd in cog.get_commands() if cmd.checks and any('is_bot_admin' in c.__qualname__ or 'is_owner' in c.__qualname__ or 'has_permissions' in c.__qualname__ or 'is_bot_support' in c.__qualname__ for c in cmd.checks)]
            if cog_admin_commands: admin_commands_by_cog[cog_name] = cog_admin_commands
        if not admin_commands_by_cog: embed.description = "Không tìm thấy lệnh admin nào."
        for cog_name, commands_list in admin_commands_by_cog.items():
            details = [f"**`!{cmd.name}`**: {cmd.help or 'Không có mô tả'}" for cmd in commands_list]
            embed.add_field(name=f"🗂️ {cog_name}", value="\n".join(details), inline=False)
        await ctx.send(embed=embed)

    @commands.command(name="listbox", aliases=['listserver'], help="[OWNER] Liệt kê tất cả server bot đang tham gia.")
    @commands.is_owner()
    async def listbox(self, ctx):
        guilds = sorted(self.bot.guilds, key=lambda g: g.name)
        if not guilds: return await ctx.send("Bot không ở trong bất kỳ server nào.")
        view = GuildPaginatorView(ctx.author, self.bot, guilds)
        await ctx.send(embed=view.create_embed(), view=view)

    @commands.group(name="permission", aliases=['perm'], invoke_without_command=True, help="[OWNER] Quản lý quyền hạn Admin và Support.")
    @commands.is_owner()
    async def permission(self, ctx): await ctx.send_help(ctx.command)

    @permission.command(name="addadmin", help="Thêm một Bot Admin.")
    async def add_admin(self, ctx, member: discord.Member):
        admins = self.permissions_data.setdefault("bot_admins", []);
        if member.id in admins: return await ctx.send(f"**{member.display_name}** đã là Bot Admin rồi.")
        admins.append(member.id); self.save_permissions_data()
        await ctx.send(f"✅ Đã cấp quyền **Bot Admin** cho **{member.display_name}**.")

    @permission.command(name="addsp", help="Thêm một Bot Support.")
    async def add_support(self, ctx, member: discord.Member):
        supports = self.permissions_data.setdefault("bot_support", [])
        if member.id in supports: return await ctx.send(f"**{member.display_name}** đã là Bot Support rồi.")
        supports.append(member.id); self.save_permissions_data()
        await ctx.send(f"✅ Đã cấp quyền **Bot Support** cho **{member.display_name}**.")

    @permission.command(name="deladmin", help="Xóa Bot Admin theo số thứ tự.")
    async def del_admin(self, ctx, index: int):
        admins = self.permissions_data.setdefault("bot_admins", [])
        if 1 <= index <= len(admins):
            user = await self.bot.fetch_user(admins.pop(index - 1)); self.save_permissions_data()
            await ctx.send(f"✅ Đã xóa quyền Bot Admin của **{user.display_name}**.")
        else: await ctx.send("❌ Số thứ tự không hợp lệ. Dùng `!listadmins`.")

    @permission.command(name="delsp", help="Xóa Bot Support theo số thứ tự.")
    async def del_support(self, ctx, index: int):
        supports = self.permissions_data.setdefault("bot_support", [])
        if 1 <= index <= len(supports):
            user = await self.bot.fetch_user(supports.pop(index - 1)); self.save_permissions_data()
            await ctx.send(f"✅ Đã xóa quyền Bot Support của **{user.display_name}**.")
        else: await ctx.send("❌ Số thứ tự không hợp lệ. Dùng `!listsupport`.")

    @is_bot_admin()
    @commands.command(name="listadmins", help="[ADMIN] Xem danh sách các Bot Admin.")
    async def list_admins(self, ctx):
        admin_ids = self.permissions_data.get("bot_admins", [])
        embed = discord.Embed(title="👑 Danh Sách Bot Admin 👑", color=discord.Color.red())
        if not admin_ids: embed.description = "Hiện chưa có Bot Admin nào."
        else: embed.description = "\n".join([f"**{i+1}.** <@{admin_id}> (`{admin_id}`)" for i, admin_id in enumerate(admin_ids)])
        await ctx.send(embed=embed)

    @is_bot_admin()
    @commands.command(name="listsupport", help="[ADMIN] Xem danh sách các Bot Support.")
    async def list_support(self, ctx):
        support_ids = self.permissions_data.get("bot_support", [])
        embed = discord.Embed(title="🔰 Danh Sách Bot Support 🔰", color=discord.Color.blue())
        if not support_ids: embed.description = "Hiện chưa có Bot Support nào."
        else: embed.description = "\n".join([f"**{i+1}.** <@{support_id}> (`{support_id}`)" for i, support_id in enumerate(support_ids)])
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Admin(bot))