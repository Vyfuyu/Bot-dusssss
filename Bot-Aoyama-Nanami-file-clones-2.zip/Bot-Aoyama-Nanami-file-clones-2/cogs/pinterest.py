# cogs/pinterest.py (Phiên bản cuối cùng, đã sửa lỗi format yt-dlp)

import discord
from discord.ext import commands
import yt_dlp
import os
import asyncio
import functools
import io
import re
import json
import aiohttp

# --- CẤU HÌNH ---
DATA_FOLDER = "data"
PINTEREST_CHANNELS_FILE = os.path.join(DATA_FOLDER, "pinterest_auto_channels.json")

# Tạo thư mục để lưu file tạm thời nếu chưa có
if not os.path.exists('downloads'):
    os.makedirs('downloads')

# --- VIEW VỚI NÚT TẢI MP3 ---
class PinActionView(discord.ui.View):
    def __init__(self, *, video_filepath: str, title: str, timeout=300):
        super().__init__(timeout=timeout)
        self.video_filepath = video_filepath
        self.filename = "".join(x for x in title if x.isalnum() or x in " _-").strip() or "pinterest_audio"
        self.is_used = False

    async def on_timeout(self):
        for item in self.children: item.disabled = True
        try:
            if self.message: await self.message.edit(view=self)
        except discord.NotFound:
            pass

    @discord.ui.button(label="Tải MP3 🎵", style=discord.ButtonStyle.success)
    async def download_mp3_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.is_used:
            return await interaction.response.send_message("Nút này đã được sử dụng.", ephemeral=True)
        self.is_used = True
        button.disabled = True; button.label = "Đang chuyển đổi..."
        await interaction.response.edit_message(view=self)

        loop = asyncio.get_event_loop()
        output_mp3_path = f"downloads/{self.filename}.mp3"
        try:
            ffmpeg_command = f'ffmpeg -i "{self.video_filepath}" -vn -ab 192k -y "{output_mp3_path}"'
            await loop.run_in_executor(None, lambda: os.system(ffmpeg_command))
            if os.path.exists(output_mp3_path):
                mp3_file = discord.File(output_mp3_path)
                await interaction.followup.send(f"🎧 Đây là file MP3 cho **{interaction.user.mention}**:", file=mp3_file)
                os.remove(output_mp3_path)
            else:
                await interaction.followup.send("❌ Rất tiếc, không thể chuyển đổi video này sang MP3.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Đã có lỗi xảy ra khi chuyển đổi: {e}", ephemeral=True)
        finally: 
            self.stop()
            # Xóa file video gốc sau khi đã xử lý xong
            if os.path.exists(self.video_filepath):
                os.remove(self.video_filepath)


class Pinterest(commands.Cog):
    """Tải và tự động xử lý link từ Pinterest."""
    def __init__(self, bot):
        self.bot = bot
        self.session = aiohttp.ClientSession()
        self.active_channels = self.load_active_channels()
        self.pinterest_regex = re.compile(r'https?:\/\/(?:www\.)?(?:pinterest\.com|pin\.it)\S+')

    def cog_unload(self):
        if self.session:
            self.bot.loop.create_task(self.session.close())

    def load_active_channels(self):
        if not os.path.exists(DATA_FOLDER): os.makedirs(DATA_FOLDER)
        if not os.path.exists(PINTEREST_CHANNELS_FILE): return set()
        with open(PINTEREST_CHANNELS_FILE, 'r') as f:
            try: return set(json.load(f))
            except json.JSONDecodeError: return set()

    def save_active_channels(self):
        with open(PINTEREST_CHANNELS_FILE, 'w') as f: json.dump(list(self.active_channels), f)

    def run_blocking_yt_dlp(self, opts, url):
        with yt_dlp.YoutubeDL(opts) as ydl:
            try: return ydl.extract_info(url, download=True)
            except Exception as e: print(f"Lỗi yt-dlp: {e}"); return None

    async def process_pin_url(self, channel: discord.TextChannel, url: str, author: discord.User):
        """Hàm chung để xử lý link Pinterest bằng cách tải trực tiếp."""
        processing_message = await channel.send(f"⏳ Đang phân tích link Pinterest từ {author.mention}...")
        loop = asyncio.get_event_loop()

        try:
            output_template = f'downloads/{author.id}_%(id)s.%(ext)s'

            # --- ĐÃ SỬA LỖI ---
            # Xóa dòng 'format': 'best' để yt-dlp tự động chọn định dạng phù hợp nhất
            dl_opts = {
                'quiet': True,
                'noplaylist': True,
                'outtmpl': output_template,
            }

            download_result = await loop.run_in_executor(None, self.run_blocking_yt_dlp, dl_opts, url)

            if not download_result:
                return await processing_message.edit(content="❌ Không thể tải về. Link có thể là story, video riêng tư hoặc không được hỗ trợ.")

            filepath = download_result.get('requested_downloads', [{}])[0].get('filepath')
            if not (filepath and os.path.exists(filepath)):
                return await processing_message.edit(content="❌ Lỗi: Không tìm thấy file sau khi tải.")

            file_size = os.path.getsize(filepath)
            title = download_result.get('title', 'Nội dung từ Pinterest')
            embed = discord.Embed(title=title, url=download_result.get('webpage_url'), color=discord.Color.red())
            embed.set_author(name=download_result.get('uploader', 'Không rõ tác giả'))
            if download_result.get('thumbnail'): embed.set_image(url=download_result.get('thumbnail'))
            embed.set_footer(text=f"Yêu cầu bởi {author.display_name}")

            view = discord.ui.View()
            is_video = download_result.get('duration') is not None

            if file_size > channel.guild.filesize_limit:
                embed.description = f"**⚠️ File quá lớn ({file_size / 1024 / 1024:.2f} MB)!**"
                await processing_message.edit(content="", embed=embed)
                os.remove(filepath) # Xóa file tạm vì không gửi được
            else:
                if is_video:
                    view = PinActionView(video_filepath=filepath, title=download_result.get('id', 'audio'))

                file_to_send = discord.File(filepath, filename=os.path.basename(filepath))
                sent_message = await channel.send(embed=embed, file=file_to_send, view=view)

                if isinstance(view, PinActionView): view.message = sent_message
                await processing_message.delete()

                if not is_video and os.path.exists(filepath):
                     os.remove(filepath)
        except Exception as e:
            await processing_message.edit(content=f"❌ Lỗi: Không thể xử lý link này.")
            print(f"Lỗi chi tiết process_pin_url: {e}")

    @commands.command(name="pin", aliases=['pinterest'], help="Tải video/ảnh từ link Pinterest.")
    @commands.cooldown(1, 15, commands.BucketType.user)
    async def pin_download(self, ctx, url: str):
        try: 
            if ctx.message: await ctx.message.delete()
        except: pass
        await self.process_pin_url(ctx.channel, url, ctx.author)

    @commands.group(name="autopin", help="Bật/tắt tính năng tự động tải từ link Pinterest.")
    @commands.has_permissions(manage_channels=True)
    async def autopin(self, ctx):
        if ctx.invoked_subcommand is None: await ctx.send_help(ctx.command)

    @autopin.command(name="on", help="Bật tính năng trong kênh này.")
    async def autopin_on(self, ctx):
        self.active_channels.add(ctx.channel.id); self.save_active_channels()
        await ctx.send(f"✅ Tính năng tự động tải Pinterest đã được **bật** cho kênh {ctx.channel.mention}.")

    @autopin.command(name="off", help="Tắt tính năng trong kênh này.")
    async def autopin_off(self, ctx):
        if ctx.channel.id in self.active_channels:
            self.active_channels.remove(ctx.channel.id); self.save_active_channels()
            await ctx.send(f"❌ Tính năng tự động tải Pinterest đã được **tắt** cho kênh {ctx.channel.mention}.")
        else: await ctx.send("Tính năng này vốn đã tắt trong kênh này.")

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or message.channel.id not in self.active_channels: return
        match = self.pinterest_regex.search(message.content)
        if not match: return
        pin_url = match.group(0)
        try: await message.delete()
        except: pass
        await self.process_pin_url(message.channel, pin_url, message.author)

async def setup(bot):
    await bot.add_cog(Pinterest(bot))