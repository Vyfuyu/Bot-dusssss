# cogs/fishing.py

import discord
from discord.ext import commands
import json
import os
import random
from datetime import datetime, timedelta

FISHING_COOLDOWN_SECONDS = 60
DATA_FOLDER = "data"
# Đổi tên file data để không bị xung đột với file cũ
USER_DATA_FILE = os.path.join(DATA_FOLDER, "fishing_inventory.json")

FISH_LIST = [
    ("Cá Diêu Hồng", 10, 'common'), ("Cá Chép", 15, 'common'), ("Cá Rô Phi", 8, 'common'),
    ("Chiếc Ủng Cũ", 1, 'common'), ("Cá Tráp", 25, 'uncommon'), ("Cá Lóc", 30, 'uncommon'),
    ("Rong Biển", 2, 'uncommon'), ("Cá Hồi", 75, 'rare'), ("Lươn Điện", 100, 'rare'),
    ("Cá Ngừ Vây Xanh", 250, 'legendary'), ("Rương Báu", 500, 'legendary')
]
RARITY_WEIGHTS = {'common': 60, 'uncommon': 25, 'rare': 10, 'legendary': 5}

class Fishing(commands.Cog):
    """Các lệnh liên quan đến trò chơi câu cá."""
    def __init__(self, bot):
        self.bot = bot
        self.user_data = self.load_user_data()

    def load_user_data(self):
        if not os.path.exists(DATA_FOLDER): os.makedirs(DATA_FOLDER)
        if not os.path.exists(USER_DATA_FILE): return {}
        try:
            with open(USER_DATA_FILE, 'r', encoding='utf-8') as f: return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError): return {}

    def save_user_data(self):
        with open(USER_DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.user_data, f, indent=4, ensure_ascii=False)

    def get_user_entry(self, user_id):
        user_id_str = str(user_id)
        if user_id_str not in self.user_data:
            # Bỏ 'balance', chỉ quản lý inventory và cooldown
            self.user_data[user_id_str] = {"inventory": {}, "last_fish": None}
        return self.user_data[user_id_str]

    @commands.command(name='câu', aliases=['fish'], help='Đi câu cá!')
    async def fish(self, ctx):
        user_id = ctx.author.id
        user_entry = self.get_user_entry(user_id)

        if user_entry["last_fish"]:
            last_fish_time = datetime.fromisoformat(user_entry["last_fish"])
            if datetime.now() < last_fish_time + timedelta(seconds=FISHING_COOLDOWN_SECONDS):
                time_left = round((last_fish_time + timedelta(seconds=FISHING_COOLDOWN_SECONDS) - datetime.now()).total_seconds())
                return await ctx.send(f"🎣 **{ctx.author.display_name}**, bạn cần chờ **{time_left} giây** nữa!")

        rarities = [item[2] for item in FISH_LIST]
        weights = [RARITY_WEIGHTS[r] for r in rarities]
        chosen_rarity = random.choices(rarities, weights=weights, k=1)[0]
        possible_catches = [item for item in FISH_LIST if item[2] == chosen_rarity]
        item_name, item_value, item_rarity = random.choice(possible_catches)

        user_entry["last_fish"] = datetime.now().isoformat()
        user_entry["inventory"][item_name] = user_entry["inventory"].get(item_name, 0) + 1
        self.save_user_data()

        rarity_color = {'common': discord.Color.light_grey(), 'uncommon': discord.Color.green(),
                        'rare': discord.Color.blue(), 'legendary': discord.Color.purple()}
        embed = discord.Embed(
            title="🎣 Câu cá thành công!",
            description=f"**{ctx.author.display_name}** đã câu được một **{item_name}**!",
            color=rarity_color.get(item_rarity, discord.Color.default())
        )
        embed.add_field(name="Độ hiếm", value=f"`{item_rarity.capitalize()}`", inline=True)
        embed.add_field(name="Giá trị", value=f"`{item_value} 💰`", inline=True)
        embed.set_footer(text=f"Dùng !cátúi để xem kho cá.")
        await ctx.send(embed=embed)

    @commands.command(name='cátúi', aliases=['fishtui'], help='Kiểm tra túi cá của bạn.')
    async def inventory_fish(self, ctx):
        user_entry = self.get_user_entry(ctx.author.id)
        inventory = user_entry.get("inventory", {})

        # Lấy thông tin tiền từ Cog Economy
        economy_cog = self.bot.get_cog('Economy')
        balance = economy_cog.get_balance(ctx.author.id) if economy_cog else "Không thể lấy"

        embed = discord.Embed(title=f"🎒 Túi đồ của {ctx.author.display_name}", color=discord.Color.blue())
        embed.add_field(name="💰 Aoyama Coin", value=f"**{balance}**", inline=False)
        if not inventory:
            embed.add_field(name="🐟 Kho cá", value="Túi cá của bạn trống trơn!", inline=False)
        else:
            fish_list = "\n".join([f"**{name}**: x{quantity}" for name, quantity in inventory.items()])
            embed.add_field(name="🐟 Kho cá", value=fish_list, inline=False)
        await ctx.send(embed=embed)

    @commands.command(name='báncá', aliases=['sellfish'], help='Bán cá để lấy Aoyama Coin.')
    async def sell_fish(self, ctx, *, item_to_sell: str):
        user_entry = self.get_user_entry(ctx.author.id)
        inventory = user_entry.get("inventory", {})

        # Logic tìm cá và số lượng để bán (giữ nguyên)
        parts = item_to_sell.lower().rsplit(' ', 1)
        item_name_input = parts[0]
        amount_to_sell = "all"
        if len(parts) > 1 and parts[1].isdigit():
            amount_to_sell = int(parts[1])
        elif len(parts) > 1 and parts[1] == 'all':
            item_name_input = parts[0]
        else:
            item_name_input = item_to_sell.lower()
            amount_to_sell = 1

        found_item_name = next((name for name in inventory if item_name_input == name.lower()), None)
        if not found_item_name:
            return await ctx.send(f"❌ Không tìm thấy `{item_to_sell}` trong túi cá.")

        item_count_in_inv = inventory[found_item_name]
        if amount_to_sell == 'all': amount_to_sell = item_count_in_inv
        if amount_to_sell <= 0 or amount_to_sell > item_count_in_inv:
            return await ctx.send(f"❌ Số lượng không hợp lệ.")

        item_value = next((fish[1] for fish in FISH_LIST if fish[0] == found_item_name), 0)
        earnings = item_value * amount_to_sell

        # *** THAY ĐỔI QUAN TRỌNG: GỌI COG ECONOMY ĐỂ CỘNG TIỀN ***
        economy_cog = self.bot.get_cog('Economy')
        if not economy_cog:
            return await ctx.send("Lỗi: Không thể kết nối đến hệ thống kinh tế.")

        economy_cog.add_balance(ctx.author.id, earnings)

        user_entry["inventory"][found_item_name] -= amount_to_sell
        if user_entry["inventory"][found_item_name] == 0:
            del user_entry["inventory"][found_item_name]
        self.save_user_data()

        await ctx.send(f"✅ Bạn đã bán **{amount_to_sell} {found_item_name}** và nhận được **{earnings}** Aoyama Coin.")

async def setup(bot):
    await bot.add_cog(Fishing(bot))