# cogs/ludo.py

import discord
from discord.ext import commands
import json
import os
from PIL import Image, ImageDraw, ImageFont
import io

# --- CẤU HÌNH CỜ CÁ NGỰA ---
DATA_FOLDER = "data"
LUDO_GAMES_FILE = os.path.join(DATA_FOLDER, "ludo_games.json")
BOARD_SIZE = 600
CELL_SIZE = BOARD_SIZE // 15
PLAYER_COLORS = {
    1: (255, 0, 0, 255),    # Đỏ
    2: (0, 0, 255, 255),    # Xanh Dương
    3: (0, 255, 0, 255),    # Xanh Lá
    4: (255, 255, 0, 255)   # Vàng
}

# (Bạn sẽ cần thêm tọa độ cho từng ô trên bàn cờ ở đây)
# Đây là phần phức tạp nhất, đòi hỏi tính toán tọa độ X, Y cho từng ô
# Ví dụ đơn giản hóa:
PATH_COORDS = [...] 

class Ludo(commands.Cog):
    """Nền tảng cho game Cờ Cá Ngựa."""
    def __init__(self, bot):
        self.bot = bot
        self.games = self.load_games()

    def load_games(self):
        # Tải các ván cờ đang diễn ra
        if not os.path.exists(LUDO_GAMES_FILE): return {}
        try:
            with open(LUDO_GAMES_FILE, 'r') as f: return json.load(f)
        except json.JSONDecodeError: return {}

    def save_games(self):
        # Lưu lại trạng thái các ván cờ
        with open(LUDO_GAMES_FILE, 'w') as f:
            json.dump(self.games, f, indent=4)

    def draw_board(self, game_state):
        # Hàm này sẽ vẽ bàn cờ dựa trên trạng thái game
        # Đây là một hàm phức tạp, dưới đây là phiên bản đơn giản hóa
        img = Image.new('RGB', (BOARD_SIZE, BOARD_SIZE), color = 'white')
        draw = ImageDraw.Draw(img)

        # Vẽ các đường kẻ
        for i in range(16):
            draw.line([(0, i * CELL_SIZE), (BOARD_SIZE, i * CELL_SIZE)], fill='black')
            draw.line([(i * CELL_SIZE, 0), (i * CELL_SIZE, BOARD_SIZE)], fill='black')

        # Vẽ "chuồng"
        draw.rectangle([0, 0, 6*CELL_SIZE, 6*CELL_SIZE], fill=PLAYER_COLORS[1])
        draw.rectangle([9*CELL_SIZE, 0, 15*CELL_SIZE, 6*CELL_SIZE], fill=PLAYER_COLORS[2])
        draw.rectangle([0, 9*CELL_SIZE, 6*CELL_SIZE, 15*CELL_SIZE], fill=PLAYER_COLORS[3])
        draw.rectangle([9*CELL_SIZE, 9*CELL_SIZE, 15*CELL_SIZE, 15*CELL_SIZE], fill=PLAYER_COLORS[4])

        # (Thêm logic vẽ các quân cờ ở vị trí của chúng)
        # for player_id, pieces in game_state['players'].items():
        #     for piece_pos in pieces:
        #         # Tính toán tọa độ x, y từ piece_pos
        #         # draw.ellipse([x, y, x+size, y+size], fill=PLAYER_COLORS[player_id])

        # Lưu ảnh vào bộ nhớ đệm
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        buffer.seek(0)
        return discord.File(buffer, filename="board.png")

    @commands.command(name="cocangua", aliases=['ludo'], help="Bắt đầu một ván Cờ Cá Ngựa.")
    async def cocangua(self, ctx, subcommand: str = "new", *members: discord.Member):
        channel_id = str(ctx.channel.id)

        if subcommand == "new":
            if channel_id in self.games:
                return await ctx.send("❌ Một ván cờ đã đang diễn ra trong kênh này!")
            if len(members) < 1 or len(members) > 3:
                return await ctx.send("❌ Cần mời từ 1 đến 3 người chơi nữa (`!cocangua new @người1 @người2`)")

            players = {1: ctx.author.id}
            for i, member in enumerate(members):
                players[i + 2] = member.id

            # Khởi tạo trạng thái game
            self.games[channel_id] = {
                "players": {p_id: {"pieces": [-1, -1, -1, -1]} for p_id in players.values()}, # -1 là trong chuồng
                "turn": ctx.author.id,
                "dice_roll": None
            }
            self.save_games()

            board_file = self.draw_board(self.games[channel_id])
            player_mentions = ", ".join([f"<@{p_id}>" for p_id in players.values()])

            await ctx.send(f"🐴 **Ván Cờ Cá Ngựa bắt đầu!**\n**Người chơi:** {player_mentions}\nĐến lượt <@{ctx.author.id}>. Dùng `!roll` để tung xúc xắc.", file=board_file)

        # (Thêm các subcommand khác như 'roll', 'move', 'board' ở đây)

    @commands.command(name="roll", help="Tung xúc xắc trong ván Cờ Cá Ngựa.")
    async def roll(self, ctx):
        await ctx.send("Đây là lệnh tung xúc xắc (chưa hoàn thiện).")

async def setup(bot):
    await bot.add_cog(Ludo(bot))