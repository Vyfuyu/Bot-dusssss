# cogs/fo4_packs.py

import discord
from discord.ext import commands
import json
import os
import random
import asyncio

# --- CẤU HÌNH ---
DATA_FOLDER = "data"
FO4_PLAYERS_FILE = os.path.join(DATA_FOLDER, "fo4_players.json")

# Cấu hình các gói thẻ và tỉ lệ
PACKS = {
    "gold": {
        "price": 25000,
        "description": "Cơ hội cao ra cầu thủ Live và 24HR.",
        "odds": {"Live": 80, "24HR": 19.9, "24TOTY": 0.1}
    },
    "diamond": {
        "price": 100000,
        "description": "Tỉ lệ cao nhận được cầu thủ 24TOTY và cơ hội sở hữu ICON.",
        "odds": {"24HR": 69.899999, "24TOTY": 30, "ICON": 0.1, "ICON_SECRET": 0.000001}
    }
}

class FifaPackOpener(commands.Cog):
    """Mô phỏng mở gói cầu thủ FIFA Online 4."""
    def __init__(self, bot):
        self.bot = bot
        self.player_database = self.load_player_database()

    def load_player_database(self):
        if not os.path.exists(FO4_PLAYERS_FILE):
            print("LỖI: Không tìm thấy file fo4_players.json trong thư mục data.")
            return {}
        with open(FO4_PLAYERS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)

    @commands.command(name="packs", help="Xem danh sách các gói thẻ có thể mở.")
    async def list_packs(self, ctx):
        embed = discord.Embed(title="Cửa hàng Gói thẻ FIFA Online 4", color=discord.Color.blue())
        for name, data in PACKS.items():
            embed.add_field(
                name=f"Gói {name.capitalize()} ({data['price']:,} Aoyama Coin)",
                value=data['description'],
                inline=False
            )
        await ctx.send(embed=embed)

    @commands.command(name="fo4pack", help="Mở gói cầu thủ. Các gói: gold, diamond.")
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def open_pack(self, ctx, pack_name: str = "gold"):
        pack_name = pack_name.lower()
        if pack_name not in PACKS:
            return await ctx.send(f"❌ Gói không hợp lệ. Các gói hiện có: `{', '.join(PACKS.keys())}`")
        if not self.player_database:
            return await ctx.send("❌ Lỗi: Không thể tải cơ sở dữ liệu cầu thủ.")

        pack_info = PACKS[pack_name]
        pack_price = pack_info["price"]
        pack_odds = pack_info["odds"]

        economy_cog = self.bot.get_cog('Economy')
        if not economy_cog: return await ctx.send("Lỗi: Không thể kết nối hệ thống kinh tế.")

        if not economy_cog.remove_balance(ctx.author.id, pack_price):
            return await ctx.send(f"❌ Bạn không đủ **{pack_price:,}** Aoyama Coin để mở gói này!")

        # Gửi tin nhắn và ảnh GIF mở gói
        opening_embed = discord.Embed(title=f"Đang mở Gói {pack_name.capitalize()}...", color=discord.Color.gold())
        opening_embed.set_image(url="https://i.imgur.com/b2bQJc8.gif") # GIF mở pack
        opening_message = await ctx.send(embed=opening_embed)

        await asyncio.sleep(4) # Tạo kịch tính

        # Mô phỏng tỉ lệ
        seasons = list(pack_odds.keys())
        weights = list(pack_odds.values())
        chosen_season = random.choices(seasons, weights=weights, k=1)[0]

        # Chọn ngẫu nhiên một cầu thủ từ mùa thẻ đó
        chosen_player = random.choice(self.player_database[chosen_season])

        # Hiển thị kết quả
        result_embed = discord.Embed(
            title=f"✨ CHÚC MỪNG BẠN ĐÃ MỞ RA ✨",
            description=f"**{chosen_player['name']}** - Mùa: **{chosen_season}**",
            color=discord.Color.purple() if "ICON" in chosen_season else discord.Color.blue()
        )
        result_embed.add_field(name="Chỉ số OVR", value=f"**{chosen_player['ovr']}**")
        result_embed.set_image(url=chosen_player['player_img'])
        result_embed.set_thumbnail(url=chosen_player['season_img'])
        result_embed.set_footer(text=f"{ctx.author.display_name} đã tiêu {pack_price:,} Aoyama Coin")

        await opening_message.edit(embed=result_embed)

    @open_pack.error
    async def pack_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"Bạn mở gói quá nhanh! Vui lòng chờ **{error.retry_after:.1f} giây**.")

async def setup(bot):
    await bot.add_cog(FifaPackOpener(bot))