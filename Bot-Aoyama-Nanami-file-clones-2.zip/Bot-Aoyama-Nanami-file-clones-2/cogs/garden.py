# cogs/garden.py

import discord
from discord.ext import commands
import json
import os
import random
from datetime import datetime, timedelta

# --- CẤU HÌNH TRÒ CHƠI ---
DATA_FOLDER = "data"
# Đổi tên file data để không bị xung đột với file cũ
USER_DATA_FILE = os.path.join(DATA_FOLDER, "garden_inventory.json")
MAX_PLOTS = 5
MUTATION_CHANCE = 0.1

PLANT_DATA = {
    "Cây Táo": {"seed_name": "Hạt Táo", "fruit_name": "Táo", "buy_price": 10, "sell_price": 5, "growth_time": 60, "rarity": "common"},
    "Cây Cà Chua": {"seed_name": "Hạt Cà Chua", "fruit_name": "Cà Chua", "buy_price": 25, "sell_price": 15, "growth_time": 180, "rarity": "common"},
    "Cây Dâu Tây": {"seed_name": "Hạt Dâu Tây", "fruit_name": "Dâu Tây", "buy_price": 80, "sell_price": 45, "growth_time": 600, "rarity": "uncommon"},
    "Cây Kim Cương": {"seed_name": "Hạt Kim Cương", "fruit_name": "Kim Cương", "buy_price": 1000, "sell_price": 600, "growth_time": 1800, "rarity": "rare"},
    "Candy Blossom": {"seed_name": "Hạt Candy Blossom", "fruit_name": "Kẹo Nở Hoa", "buy_price": 5000, "sell_price": 2500, "growth_time": 3600, "rarity": "legendary"}
}

class Garden(commands.Cog):
    """Trồng cây, thu hoạch và bán nông sản trong khu vườn của bạn."""
    def __init__(self, bot):
        self.bot = bot
        self.user_data = self.load_user_data()

    def load_user_data(self):
        if not os.path.exists(DATA_FOLDER): os.makedirs(DATA_FOLDER)
        if not os.path.exists(USER_DATA_FILE): return {}
        try:
            with open(USER_DATA_FILE, 'r', encoding='utf-8') as f: return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError): return {}

    def save_user_data(self):
        with open(USER_DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.user_data, f, indent=4, ensure_ascii=False)

    def get_user_entry(self, user_id):
        user_id_str = str(user_id)
        if user_id_str not in self.user_data:
            # Bỏ 'balance', chỉ quản lý inventory và vườn
            self.user_data[user_id_str] = {
                "inventory": {"seeds": {}, "fruits": {}},
                "garden_plots": [None] * MAX_PLOTS,
            }
        return self.user_data[user_id_str]

    # Giữ nguyên các lệnh !vườn, !shop, !trồng, !thuhoạch (không cần sửa nhiều)
    # ... (phần code này giữ nguyên, chỉ sửa lại các lệnh có dính đến tiền)

    @commands.command(name='mua', aliases=['buy'], help='Mua hạt giống. Ví dụ: !mua Hạt Táo 5')
    async def buy(self, ctx, *, item_and_amount: str):
        # ... (phần code xử lý tên và số lượng giữ nguyên)
        parts = item_and_amount.rsplit(' ', 1)
        item_name_input = parts[0]
        amount = 1
        if len(parts) > 1 and parts[1].isdigit():
            amount = int(parts[1])

        target_plant_data = next((data for data in PLANT_DATA.values() if data['seed_name'].lower() == item_name_input.lower()), None)
        if not target_plant_data:
            return await ctx.send(f"❌ Không tìm thấy hạt giống `{item_name_input}`.")

        # *** THAY ĐỔI QUAN TRỌNG: GỌI COG ECONOMY ĐỂ KIỂM TRA VÀ TRỪ TIỀN ***
        economy_cog = self.bot.get_cog('Economy')
        if not economy_cog:
            return await ctx.send("Lỗi: Không thể kết nối đến hệ thống kinh tế.")

        cost = target_plant_data['buy_price'] * amount
        if economy_cog.get_balance(ctx.author.id) < cost:
            return await ctx.send(f"❌ Bạn không đủ Aoyama Coin! Cần {cost} 💰.")

        if economy_cog.remove_balance(ctx.author.id, cost):
            user_entry = self.get_user_entry(ctx.author.id)
            seed_name = target_plant_data['seed_name']
            user_entry['inventory']['seeds'][seed_name] = user_entry['inventory']['seeds'].get(seed_name, 0) + amount
            self.save_user_data()
            await ctx.send(f"✅ Đã mua thành công **{amount} {seed_name}** với giá **{cost}** Aoyama Coin.")
        else:
            await ctx.send("Lỗi giao dịch, vui lòng thử lại.")

    @commands.command(name="vườntúi", aliases=['gardentui'], help="Xem hạt giống và hoa quả của bạn.")
    async def inventory_garden(self, ctx):
        user_entry = self.get_user_entry(ctx.author.id)

        economy_cog = self.bot.get_cog('Economy')
        balance = economy_cog.get_balance(ctx.author.id) if economy_cog else "Không thể lấy"

        embed = discord.Embed(title=f"🎒 Túi đồ của {ctx.author.display_name}", color=discord.Color.orange())
        embed.add_field(name="💰 Aoyama Coin", value=f"**{balance}**", inline=False)

        seeds = user_entry['inventory'].get('seeds', {})
        fruits = user_entry['inventory'].get('fruits', {})

        embed.add_field(name="🌱 Hạt giống", value="\n".join([f"**{n}**: x{q}" for n, q in seeds.items()]) or "Trống", inline=True)
        embed.add_field(name="🍎 Hoa quả", value="\n".join([f"**{n}**: x{q}" for n, q in fruits.items()]) or "Trống", inline=True)

        await ctx.send(embed=embed)

    @commands.command(name="bánnôngsản", aliases=['sellgarden'], help="Bán hoa quả. Ví dụ: !bánnôngsản Táo 10")
    async def sell_garden(self, ctx, *, item_to_sell: str):
        user_entry = self.get_user_entry(ctx.author.id)
        inventory = user_entry['inventory']['fruits']

        # ... (phần code xử lý tên và số lượng giữ nguyên)
        parts = item_to_sell.rsplit(' ', 1)
        item_name_input = parts[0]
        amount = 'all'
        if len(parts) > 1 and parts[1].isdigit(): amount = int(parts[1])
        elif len(parts) > 1 and parts[1] != 'all': item_name_input = item_to_sell

        found_item_name = next((name for name in inventory if item_name_input.lower() == name.lower()), None)
        if not found_item_name: return await ctx.send("❌ Không tìm thấy hoa quả này trong túi.")

        count_in_inv = inventory[found_item_name]
        if amount == 'all': amount = count_in_inv
        if not isinstance(amount, int) or amount > count_in_inv or amount <= 0:
             return await ctx.send(f"❌ Số lượng không hợp lệ.")

        # ... (phần code xử lý đột biến và tính tiền giữ nguyên)
        multiplier, base_fruit_name = (2, found_item_name.replace(" (2x Tiền)", "")) if "(2x tiền)" in found_item_name.lower() else (1, found_item_name)
        sell_price = next((data['sell_price'] for data in PLANT_DATA.values() if data['fruit_name'] == base_fruit_name), 0)
        earnings = sell_price * amount * multiplier

        # *** THAY ĐỔI QUAN TRỌNG: GỌI COG ECONOMY ĐỂ CỘNG TIỀN ***
        economy_cog = self.bot.get_cog('Economy')
        if not economy_cog:
            return await ctx.send("Lỗi: Không thể kết nối đến hệ thống kinh tế.")

        economy_cog.add_balance(ctx.author.id, earnings)
        inventory[found_item_name] -= amount
        if inventory[found_item_name] == 0: del inventory[found_item_name]

        self.save_user_data()
        await ctx.send(f"✅ Đã bán **{amount} {found_item_name}** và nhận được **{earnings}** Aoyama Coin.")

    # (Các lệnh còn lại như !vườn, !shop, !trồng, !thuhoạch giữ nguyên gần như hoàn toàn)
    # Để cho gọn, mình sẽ không dán lại các lệnh không thay đổi ở đây.
    # Bạn chỉ cần copy toàn bộ code phía trên vào file là đủ.
    # Tuy nhiên, để đảm bảo code đầy đủ, đây là toàn bộ các lệnh còn lại:

    @commands.command(name='vườn', aliases=['garden'], help='Xem khu vườn của bạn.')
    async def garden(self, ctx):
        user_entry = self.get_user_entry(ctx.author.id)
        plots = user_entry["garden_plots"]
        embed = discord.Embed(title=f"🌳 Vườn của {ctx.author.display_name}", color=discord.Color.green())
        for i, plot in enumerate(plots):
            plot_num = i + 1
            if plot is None:
                embed.add_field(name=f"ô Đất {plot_num}", value="`Trống`", inline=True)
            else:
                plant_name, plant_time_iso = plot["plant_name"], plot["plant_time"]
                plant_time = datetime.fromisoformat(plant_time_iso)
                growth_time = timedelta(seconds=PLANT_DATA[plant_name]["growth_time"])
                harvest_time = plant_time + growth_time
                status = "**✅ Sẵn sàng!**" if datetime.now() >= harvest_time else f"⏳ Còn: {str(harvest_time - datetime.now()).split('.')[0]}"
                embed.add_field(name=f"ô Đất {plot_num}: {plant_name}", value=status, inline=True)
        await ctx.send(embed=embed)

    @commands.command(name='shop', aliases=['cửahàng'], help='Xem các loại hạt giống có thể mua.')
    async def shop(self, ctx):
        embed = discord.Embed(title="🛒 Cửa Hàng Hạt Giống", color=discord.Color.gold())
        for name, data in PLANT_DATA.items():
            embed.add_field(name=f"{data['seed_name']} ({data['rarity'].capitalize()})", value=f"**Giá:** {data['buy_price']} 💰\n**Lớn trong:** {data['growth_time'] // 60}p", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name='trồng', aliases=['plant'], help='Trồng cây. Ví dụ: !trồng "Cây Táo" 1')
    async def plant(self, ctx, plant_name_input: str, plot_num_str: str):
        if not plot_num_str.isdigit() or not (1 <= int(plot_num_str) <= MAX_PLOTS):
            return await ctx.send(f"❌ Ô đất không hợp lệ (1-{MAX_PLOTS}).")
        plot_num = int(plot_num_str)
        user_entry = self.get_user_entry(ctx.author.id)
        plot_index = plot_num - 1
        if user_entry['garden_plots'][plot_index] is not None:
            return await ctx.send(f"❌ ô đất số {plot_num} đã có cây rồi!")
        target_plant_data = next((data for name, data in PLANT_DATA.items() if name.lower() == plant_name_input.lower()), None)
        if not target_plant_data:
            return await ctx.send(f"❌ Không tìm thấy cây `{plant_name_input}`.")
        seed_name = target_plant_data['seed_name']
        if user_entry['inventory']['seeds'].get(seed_name, 0) < 1:
            return await ctx.send(f"❌ Bạn không có **{seed_name}**.")
        user_entry['inventory']['seeds'][seed_name] -= 1
        user_entry['garden_plots'][plot_index] = {"plant_name": next(k for k, v in PLANT_DATA.items() if v == target_plant_data), "plant_time": datetime.now().isoformat()}
        self.save_user_data()
        await ctx.send(f"✅ Đã trồng **{next(k for k, v in PLANT_DATA.items() if v == target_plant_data)}** vào ô đất số **{plot_num}**!")

    @commands.command(name='thuhoạch', aliases=['harvest'], help='Thu hoạch cây. Ví dụ: !thuhoạch 1')
    async def harvest(self, ctx, plot_num_str: str):
        user_entry = self.get_user_entry(ctx.author.id)
        if plot_num_str.lower() == 'all':
            harvested_summary = {}
            for i in range(MAX_PLOTS):
                fruit_name, _ = self.check_and_harvest_plot(user_entry, i) or (None, None)
                if fruit_name: harvested_summary[fruit_name] = harvested_summary.get(fruit_name, 0) + 1
            if not harvested_summary: return await ctx.send("Không có cây nào để thu hoạch.")
            summary_text = "\n".join([f"x{q} {n}" for n, q in harvested_summary.items()])
            self.save_user_data()
            return await ctx.send(f"🎉 Đã thu hoạch tất cả!\n**Nhận được:**\n{summary_text}")

        if not plot_num_str.isdigit() or not (1 <= int(plot_num_str) <= MAX_PLOTS):
            return await ctx.send(f"❌ Ô đất không hợp lệ.")

        plot_index = int(plot_num_str) - 1
        fruit_name, is_mutated = self.check_and_harvest_plot(user_entry, plot_index) or (None, None)
        if not fruit_name: return await ctx.send("❌ Cây này chưa lớn hoặc ô đất trống.")
        self.save_user_data()
        message = f"🎉 Bạn đã thu hoạch được 1 **{fruit_name}**!"
        if is_mutated:
            embed = discord.Embed(title="🌟 ĐỘT BIẾN! 🌟", description=f"{message}\n\nCây của bạn sẽ được nhân đôi giá trị!", color=discord.Color.magenta())
            await ctx.send(embed=embed)
        else: await ctx.send(message)

    def check_and_harvest_plot(self, user_entry, plot_index):
        plot_data = user_entry['garden_plots'][plot_index]
        if not plot_data: return None
        plant_name, plant_time_iso = plot_data["plant_name"], plot_data["plant_time"]
        plant_time = datetime.fromisoformat(plant_time_iso)
        if datetime.now() < plant_time + timedelta(seconds=PLANT_DATA[plant_name]["growth_time"]): return None
        fruit_name = PLANT_DATA[plant_name]["fruit_name"]
        is_mutated = random.random() < MUTATION_CHANCE
        if is_mutated: fruit_name += " (2x Tiền)"
        user_entry['inventory']['fruits'][fruit_name] = user_entry['inventory']['fruits'].get(fruit_name, 0) + 1
        user_entry['garden_plots'][plot_index] = None
        return fruit_name, is_mutated

async def setup(bot):
    await bot.add_cog(Garden(bot))