# cogs/minigames.py

import discord
from discord.ext import commands
import random
import asyncio

# --- NÚT BẤM CHO GAME KÉO BÚA BAO ---
class RockPaperScissorsView(discord.ui.View):
    def __init__(self, author, bet):
        super().__init__(timeout=60) # View hết hạn sau 60s
        self.author = author
        self.bet = bet
        self.player_choice = None
        self.bot_choice = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        # Chỉ cho phép người dùng đã gọi lệnh tương tác
        if interaction.user != self.author:
            await interaction.response.send_message("Đây không phải trò chơi của bạn!", ephemeral=True)
            return False
        return True

    async def handle_game_end(self, interaction: discord.Interaction):
        # Vô hiệu hóa tất cả các nút
        for item in self.children:
            item.disabled = True
        await interaction.message.edit(view=self)
        self.stop()

    @discord.ui.button(label="Búa 🗿", style=discord.ButtonStyle.secondary)
    async def rock(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.player_choice = "búa"
        await self.resolve_game(interaction)

    @discord.ui.button(label="Bao 📜", style=discord.ButtonStyle.secondary)
    async def paper(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.player_choice = "bao"
        await self.resolve_game(interaction)

    @discord.ui.button(label="Kéo ✂️", style=discord.ButtonStyle.secondary)
    async def scissors(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.player_choice = "kéo"
        await self.resolve_game(interaction)

    async def resolve_game(self, interaction: discord.Interaction):
        self.bot_choice = random.choice(["búa", "bao", "kéo"])
        choices_map = {"búa": "🗿", "bao": "📜", "kéo": "✂️"}

        result_text = ""
        win = False
        tie = False

        if self.player_choice == self.bot_choice:
            result_text = "Kết quả: **Hòa!** 🤝"
            tie = True
        elif (self.player_choice == "búa" and self.bot_choice == "kéo") or \
             (self.player_choice == "bao" and self.bot_choice == "búa") or \
             (self.player_choice == "kéo" and self.bot_choice == "bao"):
            result_text = "Kết quả: **Bạn thắng!** 🎉"
            win = True
        else:
            result_text = "Kết quả: **Bạn thua!** 😢"

        description = f"Bạn chọn: **{choices_map[self.player_choice]}**\nBot chọn: **{choices_map[self.bot_choice]}\n\n{result_text}"

        # Xử lý tiền cược
        if self.bet > 0:
            economy_cog = self.bot.get_cog('Economy')
            if win:
                economy_cog.add_balance(self.author.id, self.bet)
                description += f"\nBạn thắng **{self.bet}** Aoyama Coin!"
            elif not tie: # Thua
                # Tiền đã bị trừ lúc bắt đầu game
                description += f"\nBạn mất **{self.bet}** Aoyama Coin."

        embed = discord.Embed(title="Kéo Búa Bao", description=description, color=discord.Color.blue())
        await interaction.response.edit_message(embed=embed)
        await self.handle_game_end(interaction)


class Minigames(commands.Cog):
    """Các minigame giải trí sử dụng Aoyama Coin."""
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="tàixỉu", aliases=['tx'], help="Thử vận may với game Tài Xỉu.")
    async def taixiu(self, ctx, choice: str, bet: int):
        choice = choice.lower()
        if choice not in ['tài', 'xỉu']:
            return await ctx.send("❌ Vui lòng chọn `tài` hoặc `xỉu`.")
        if bet <= 0:
            return await ctx.send("❌ Số tiền cược phải lớn hơn 0.")

        economy_cog = self.bot.get_cog('Economy')
        if not economy_cog:
            return await ctx.send("Lỗi: Không thể kết nối hệ thống kinh tế.")

        # Kiểm tra và trừ tiền cược trước
        if not economy_cog.remove_balance(ctx.author.id, bet):
            return await ctx.send(f"❌ Bạn không đủ Aoyama Coin để cược {bet}!")

        # Tung 3 xúc xắc
        dice = [random.randint(1, 6) for _ in range(3)]
        total = sum(dice)
        dice_emojis = [str(d).replace('1', '⚀').replace('2', '⚁').replace('3', '⚂').replace('4', '⚃').replace('5', '⚄').replace('6', '⚅') for d in dice]

        embed = discord.Embed(title="🎲 Game Tài Xỉu 🎲", color=discord.Color.red())
        embed.add_field(name="Xúc xắc", value=" ".join(dice_emojis), inline=False)
        embed.add_field(name="Tổng điểm", value=f"**{total}**", inline=False)

        # Xác định kết quả
        is_triplets = len(set(dice)) == 1
        win = False

        if is_triplets:
            result_text = f"Kết quả: **Bộ ba đồng nhất!** Nhà cái ăn."
            embed.color = discord.Color.dark_red()
        elif 4 <= total <= 10:
            result_text = "Kết quả: **Xỉu**"
            embed.color = discord.Color.black()
            if choice == 'xỉu':
                win = True
        else: # 11 <= total <= 17
            result_text = "Kết quả: **Tài**"
            embed.color = discord.Color.orange()
            if choice == 'tài':
                win = True

        embed.add_field(name="Kết quả", value=result_text, inline=False)

        # Trả thưởng
        if win:
            winnings = bet * 2 # Nhận lại tiền cược + tiền thắng
            economy_cog.add_balance(ctx.author.id, winnings)
            embed.description = f"🎉 **{ctx.author.display_name}** đã thắng **{bet}** Aoyama Coin!"
        else:
            embed.description = f"😢 **{ctx.author.display_name}** đã mất **{bet}** Aoyama Coin."

        await ctx.send(embed=embed)

    @commands.command(name="kéobúabao", aliases=['kbb', 'rps'], help="Chơi Kéo Búa Bao với bot.")
    async def rock_paper_scissors(self, ctx, bet: int = 0):
        if bet < 0:
            return await ctx.send("❌ Không thể cược số tiền âm!")

        economy_cog = self.bot.get_cog('Economy')
        if bet > 0:
            if not economy_cog:
                return await ctx.send("Lỗi: Không thể kết nối hệ thống kinh tế.")
            if not economy_cog.remove_balance(ctx.author.id, bet):
                return await ctx.send(f"❌ Bạn không đủ Aoyama Coin để cược {bet}!")

        embed = discord.Embed(
            title="Kéo Búa Bao",
            description=f"**{ctx.author.display_name}**, hãy chọn một trong các nút bên dưới.",
            color=discord.Color.blue()
        )
        if bet > 0:
            embed.set_footer(text=f"Tiền cược: {bet} Aoyama Coin")

        view = RockPaperScissorsView(author=ctx.author, bet=bet)
        view.bot = self.bot # Truyền bot instance vào view
        await ctx.send(embed=embed, view=view)


async def setup(bot):
    await bot.add_cog(Minigames(bot))