# cogs/weather.py

import discord
from discord.ext import commands, tasks
import json
import os
import aiohttp
from datetime import datetime, timedelta

# --- CẤU HÌNH WEATHER ---
DATA_FOLDER = "data"
SUBSCRIPTIONS_FILE = os.path.join(DATA_FOLDER, "weather_subscriptions.json")

class Weather(commands.Cog):
    """Kiểm tra thời tiết và tự động cập nhật."""
    def __init__(self, bot):
        self.bot = bot
        self.api_key = os.environ.get('OPENWEATHER_API_KEY')
        self.session = aiohttp.ClientSession()
        self.subscriptions = self.load_subscriptions()

        if not self.api_key:
            print("❌ Không tìm thấy OPENWEATHER_API_KEY. Tính năng thời tiết sẽ không hoạt động.")
        else:
            # Khởi động vòng lặp chạy nền
            self.weather_update_loop.start()
            print("✅ Vòng lặp cập nhật thời tiết đã bắt đầu.")

    def cog_unload(self):
        # Đảm bảo vòng lặp được hủy khi cog bị gỡ bỏ
        self.weather_update_loop.cancel()
        # Đóng phiên làm việc aiohttp
        if self.session:
            self.bot.loop.create_task(self.session.close())

    # --- HÀM QUẢN LÝ DỮ LIỆU ĐĂNG KÝ ---
    def load_subscriptions(self):
        if not os.path.exists(DATA_FOLDER): os.makedirs(DATA_FOLDER)
        if not os.path.exists(SUBSCRIPTIONS_FILE): return {}
        try:
            with open(SUBSCRIPTIONS_FILE, 'r') as f: return json.load(f)
        except json.JSONDecodeError: return {}

    def save_subscriptions(self):
        with open(SUBSCRIPTIONS_FILE, 'w') as f:
            json.dump(self.subscriptions, f, indent=4)

    # --- HÀM LẤY VÀ ĐỊNH DẠNG DỮ LIỆU THỜI TIẾT ---
    async def get_weather_embed(self, city: str):
        if not self.api_key: return None

        base_url = "http://api.openweathermap.org/data/2.5/weather"
        params = {
            'q': city,
            'appid': self.api_key,
            'units': 'metric', # Để nhiệt độ là độ C
            'lang': 'vi'      # Ngôn ngữ tiếng Việt
        }

        try:
            async with self.session.get(base_url, params=params) as response:
                if response.status != 200:
                    error_text = await response.text()
                    embed = discord.Embed(title=f"Lỗi khi tìm thành phố `{city}`", description=f"API trả về lỗi: {error_text}", color=discord.Color.red())
                    return embed

                data = await response.json()

            # Lấy thông tin từ JSON
            main = data['main']
            wind = data['wind']
            weather_desc = data['weather'][0]['description'].capitalize()
            weather_icon = data['weather'][0]['icon']

            # Tính toán thời gian tại địa phương
            timezone_offset = data['timezone']
            local_time = datetime.utcnow() + timedelta(seconds=timezone_offset)

            embed = discord.Embed(
                title=f"Thời tiết tại {data['name']}, {data['sys']['country']}",
                description=f"**{weather_desc}**",
                color=discord.Color.blue()
            )
            embed.set_thumbnail(url=f"http://openweathermap.org/img/wn/{weather_icon}@2x.png")
            embed.add_field(name="🌡️ Nhiệt độ", value=f"{main['temp']}°C", inline=True)
            embed.add_field(name="🤔 Cảm giác như", value=f"{main['feels_like']}°C", inline=True)
            embed.add_field(name="💧 Độ ẩm", value=f"{main['humidity']}%", inline=True)
            embed.add_field(name="💨 Gió", value=f"{wind['speed']} m/s", inline=True)
            embed.add_field(name="📈 Áp suất", value=f"{main['pressure']} hPa", inline=True)
            embed.set_footer(text=f"Thời gian tại địa phương: {local_time.strftime('%H:%M:%S, %d-%m-%Y')}")

            return embed
        except Exception as e:
            return discord.Embed(title="Lỗi không xác định", description=str(e), color=discord.Color.red())

    # --- CÁC LỆNH CHO NGƯỜI DÙNG ---
    @commands.group(name="thoitiet", aliases=['weather'], invoke_without_command=True, help="Kiểm tra thời tiết hoặc đăng ký cập nhật tự động.")
    async def weather(self, ctx, *, city: str):
        """Lệnh chính, nếu không có subcommand thì sẽ check thời tiết."""
        embed = await self.get_weather_embed(city)
        if embed:
            await ctx.send(embed=embed)

    @weather.command(name="sub", help="Đăng ký nhận cập nhật thời tiết mỗi 10 phút.")
    @commands.has_permissions(manage_channels=True)
    async def subscribe(self, ctx, *, city: str):
        channel_id_str = str(ctx.channel.id)
        self.subscriptions[channel_id_str] = city
        self.save_subscriptions()
        await ctx.send(f"✅ Đã đăng ký thành công! Kênh {ctx.channel.mention} sẽ nhận thông báo thời tiết cho **{city}** mỗi 10 phút.")

    @weather.command(name="unsub", help="Hủy đăng ký nhận cập nhật thời tiết.")
    @commands.has_permissions(manage_channels=True)
    async def unsubscribe(self, ctx):
        channel_id_str = str(ctx.channel.id)
        if channel_id_str in self.subscriptions:
            city = self.subscriptions.pop(channel_id_str)
            self.save_subscriptions()
            await ctx.send(f"✅ Đã hủy đăng ký nhận thông báo thời tiết cho **{city}** trong kênh này.")
        else:
            await ctx.send("❌ Kênh này chưa được đăng ký nhận thông báo.")

    # --- VÒNG LẶP NỀN TỰ ĐỘNG CẬP NHẬT ---
    @tasks.loop(minutes=10)
    async def weather_update_loop(self):
        # Tạo một bản copy để tránh lỗi nếu dict thay đổi trong lúc lặp
        for channel_id_str, city in list(self.subscriptions.items()):
            try:
                channel = self.bot.get_channel(int(channel_id_str))
                if channel:
                    embed = await self.get_weather_embed(city)
                    if embed:
                        await channel.send(content=f"**Cập nhật thời tiết tự động cho `{city}`:**", embed=embed)
                else:
                    # Nếu không tìm thấy kênh (bot bị kick, kênh bị xóa), xóa đăng ký
                    del self.subscriptions[channel_id_str]
                    self.save_subscriptions()
            except Exception as e:
                print(f"Lỗi khi cập nhật thời tiết cho kênh {channel_id_str}: {e}")

    # Đảm bảo vòng lặp chỉ bắt đầu khi bot đã sẵn sàng
    @weather_update_loop.before_loop
    async def before_weather_loop(self):
        await self.bot.wait_until_ready()

async def setup(bot):
    await bot.add_cog(Weather(bot))