# cogs/reset_manager.py

import discord
from discord.ext import commands
import json
import os

# Import hàm check quyền từ cog Admin
from .admin import is_bot_admin

DATA_FOLDER = "data"
ECONOMY_DATA_FILE = os.path.join(DATA_FOLDER, "economy_data.json")
STARTING_COINS = 100
GAME_DATA_FILES = [
    os.path.join(DATA_FOLDER, "economy_data.json"),
    os.path.join(DATA_FOLDER, "fishing_inventory.json"),
    os.path.join(DATA_FOLDER, "garden_inventory.json"),
    os.path.join(DATA_FOLDER, "tu_tien_data.json"),
]

class ResetManager(commands.Cog):
    """Chứa các lệnh reset dữ liệu nguy hiểm."""
    def __init__(self, bot):
        self.bot = bot
        self.all_data_files = GAME_DATA_FILES

    @commands.group(name="resetdata", invoke_without_command=True, help="[ADMIN] Reset dữ liệu người chơi.")
    @is_bot_admin()
    async def resetdata(self, ctx):
        await ctx.send_help(ctx.command)

    @resetdata.command(name="all", help="Reset TOÀN BỘ dữ liệu game.")
    async def reset_all_data(self, ctx, *, confirmation: str = None):
        CONFIRMATION_PHRASE = "TÔI HIỂU RÕ RỦI RO"
        if confirmation != CONFIRMATION_PHRASE:
            return await ctx.send(f"**CẢNH BÁO!**\nĐể xác nhận, gõ lại: `!resetdata all {CONFIRMATION_PHRASE}`")

        await ctx.send("⏳ Bắt đầu quá trình reset dữ liệu...")
        deleted_count, error_files = 0, []
        for file_path in self.all_data_files:
            print(f"[DEBUG] Đang thử xóa file: {file_path}")
            try:
                if os.path.exists(file_path):
                    os.remove(file_path); print(f"[DEBUG] Đã gửi lệnh xóa cho {file_path}")
                    if not os.path.exists(file_path): deleted_count += 1; print(f"[DEBUG] XÁC NHẬN: File {file_path} đã bị xóa.")
                    else: print(f"[DEBUG] LỖI: File {file_path} vẫn còn tồn tại!"); error_files.append(os.path.basename(file_path))
            except Exception as e: print(f"[DEBUG] LỖI EXCEPTION khi xóa file {file_path}: {e}"); error_files.append(os.path.basename(file_path))

        if not error_files:
            await ctx.send(f"🔥 **HOÀN TẤT!** Đã xóa **{deleted_count}** file. **Vui lòng khởi động lại bot ngay!**")
        else:
            await ctx.send(f"⚠️ **Có lỗi!** Đã xóa {deleted_count} file, nhưng không thể xóa: `{', '.join(error_files)}`. Kiểm tra console.")

    @resetdata.command(name="user", help="Reset dữ liệu game của một người dùng.")
    async def reset_user_data(self, ctx, member: discord.Member):
        user_id_to_reset = str(member.id)
        for file_path in self.all_data_files:
            if not os.path.exists(file_path): continue
            try:
                with open(file_path, 'r+', encoding='utf-8') as f:
                    data = json.load(f)
                    if user_id_to_reset in data:
                        del data[user_id_to_reset]
                        f.seek(0); f.truncate()
                        json.dump(data, f, indent=4, ensure_ascii=False)
            except Exception as e: await ctx.send(f"Lỗi khi xử lý file `{file_path}`: {e}")
        await ctx.send(f"✅ Đã reset dữ liệu game của **{member.display_name}**.")

    @commands.group(name="resetcoin", invoke_without_command=True, help="[ADMIN] Reset Aoyama Coin.")
    @is_bot_admin()
    async def resetcoin(self, ctx):
        await ctx.send_help(ctx.command)

    @resetcoin.command(name="user", help="Reset Aoyama Coin của một người về mức ban đầu.")
    async def reset_user_coin(self, ctx, member: discord.Member):
        economy_cog = self.bot.get_cog('Economy')
        if not economy_cog: return await ctx.send("❌ Lỗi: Không thể kết nối đến hệ thống kinh tế.")
        economy_cog.set_user_balance(member.id, STARTING_COINS)
        await ctx.send(f"✅ Đã reset Aoyama Coin của **{member.display_name}** về **{STARTING_COINS}**.")

    @resetcoin.command(name="all", help="Reset Aoyama Coin của TẤT CẢ người chơi.")
    async def reset_all_coin(self, ctx, *, confirmation: str = None):
        CONFIRMATION_PHRASE = "XÓA SẠCH TIỀN TỆ"
        if confirmation != CONFIRMATION_PHRASE:
            return await ctx.send(f"**CẢNH BÁO!**\nĐể xác nhận, gõ lại: `!resetcoin all {CONFIRMATION_PHRASE}`")
        try:
            if os.path.exists(ECONOMY_DATA_FILE):
                os.remove(ECONOMY_DATA_FILE)
                await ctx.send(f"🔥 **HOÀN TẤT!** Đã xóa sạch dữ liệu coin. **Vui lòng khởi động lại bot ngay!**")
            else: await ctx.send("Không có dữ liệu kinh tế để xóa.")
        except Exception as e: await ctx.send(f"Lỗi khi xóa file kinh tế: {e}")


async def setup(bot):
    await bot.add_cog(ResetManager(bot))