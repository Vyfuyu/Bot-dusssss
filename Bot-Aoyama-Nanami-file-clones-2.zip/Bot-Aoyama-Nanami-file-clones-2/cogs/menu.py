# cogs/menu.py

import discord
from discord.ext import commands
from discord.ui import View, Select

# --- PHÂN LOẠI CÁC COG VÀO CÁC DANH MỤC ---
# Bạn có thể tự do thay đổi, thêm, bớt các cog trong từng danh mục
CATEGORIZED_COGS = {
    "Trò Chơi & Giải Trí 🎮": [
        "Fishing", "Garden", "Minigames", "TuTien", "Ludo", "AoyamaAI"
    ],
    "Công Cụ & Tiện Ích 🛠️": [
        "TikTokDownloader", "Downloader", "ImageGenerator", "Weather"
    ],
    "Kinh Tế & Quản Lý 💰": [
        "Economy", "Admin", "Moderation"
    ]
}

# Lấy danh sách tất cả các cog được phân loại để tiện kiểm tra
ALL_CATEGORIZED_COGS = [cog for cogs in CATEGORIZED_COGS.values() for cog in cogs]


# --- CÁC COMPONENT CỦA VIEW ---

# Menu thả xuống để chọn Danh Mục
class CategorySelect(Select):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        options = [discord.SelectOption(label=category, description=f"Xem các lệnh trong danh mục {category.split(' ')[0]}") for category in CATEGORIZED_COGS.keys()]
        super().__init__(placeholder="Chọn một danh mục để khám phá...", options=options)

    async def callback(self, interaction: discord.Interaction):
        # Lấy danh mục đã chọn
        chosen_category = self.values[0]
        # Lấy danh sách các cog trong danh mục đó
        cogs_in_category = CATEGORIZED_COGS[chosen_category]

        # Cập nhật lại view với menu chọn cog và nút quay lại
        await self.view.show_cogs_in_category(interaction, chosen_category, cogs_in_category)

# Menu thả xuống để chọn Cog/Game cụ thể
class CogSelect(Select):
    def __init__(self, bot: commands.Bot, cogs_in_category: list):
        self.bot = bot
        options = []
        for cog_name in cogs_in_category:
            cog = bot.get_cog(cog_name)
            if cog:
                # Lấy docstring làm mô tả
                description = (cog.__doc__ or f"Các lệnh của {cog_name}")[:100]
                options.append(discord.SelectOption(label=cog_name, description=description, value=cog_name))

        super().__init__(placeholder="Chọn một tính năng để xem chi tiết...", options=options)

    async def callback(self, interaction: discord.Interaction):
        # Lấy cog đã chọn
        chosen_cog_name = self.values[0]
        # Hiển thị chi tiết lệnh của cog đó
        await self.view.show_cog_details(interaction, chosen_cog_name)

# Nút Quay Lại
class BackButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="⬅️ Quay lại Menu Chính", style=discord.ButtonStyle.grey)

    async def callback(self, interaction: discord.Interaction):
        # Quay về trạng thái ban đầu (chọn danh mục)
        await self.view.show_main_menu(interaction)


# --- VIEW CHÍNH ĐIỀU KHIỂN TOÀN BỘ MENU ---
class AdvancedMenuView(View):
    def __init__(self, bot: commands.Bot, author: discord.User):
        super().__init__(timeout=300)
        self.bot = bot
        self.author = author

        # Trạng thái ban đầu: hiển thị menu chọn danh mục
        self.add_item(CategorySelect(self.bot))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.author:
            await interaction.response.send_message("Đây không phải menu của bạn!", ephemeral=True)
            return False
        return True

    async def show_main_menu(self, interaction: discord.Interaction):
        """Hiển thị lại menu chọn danh mục ban đầu."""
        self.clear_items()
        self.add_item(CategorySelect(self.bot))
        embed = discord.Embed(
            title="📚 Menu Lệnh Bot Aoyama",
            description="Chào mừng bạn! Hãy chọn một danh mục bên dưới để khám phá các tính năng của tôi.",
            color=discord.Color.purple()
        )
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        await interaction.response.edit_message(embed=embed, view=self)

    async def show_cogs_in_category(self, interaction: discord.Interaction, category_name: str, cogs_in_category: list):
        """Hiển thị menu các game/tính năng trong một danh mục."""
        self.clear_items()
        self.add_item(CogSelect(self.bot, cogs_in_category))
        self.add_item(BackButton())
        embed = discord.Embed(
            title=f"Danh mục: {category_name}",
            description="Bây giờ, hãy chọn một tính năng cụ thể để xem chi tiết các lệnh.",
            color=discord.Color.green()
        )
        await interaction.response.edit_message(embed=embed, view=self)

    async def show_cog_details(self, interaction: discord.Interaction, cog_name: str):
        """Hiển thị chi tiết các lệnh của một cog."""
        self.clear_items()
        self.add_item(BackButton())
        cog = self.bot.get_cog(cog_name)
        embed = discord.Embed(
            title=f"📜 Lệnh của: {cog_name}",
            description=cog.__doc__ or "Dưới đây là danh sách các lệnh có sẵn:",
            color=discord.Color.gold()
        )
        for command in cog.get_commands():
            aliases = ', '.join([f"`!{alias}`" for alias in command.aliases])
            help_text = command.help or "Lệnh này chưa có mô tả."
            name_field = f"**`!{command.name}`**" + (f" ({aliases})" if aliases else "")
            embed.add_field(name=name_field, value=f"ㄴ {help_text}", inline=False)
        await interaction.response.edit_message(embed=embed, view=self)


class Menu(commands.Cog):
    """Hệ thống menu đa cấp để xem các lệnh."""
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='menu', help='Hiển thị menu lệnh đa cấp mới.')
    async def advanced_menu(self, ctx):
        view = AdvancedMenuView(self.bot, ctx.author)
        embed = discord.Embed(
            title="📚 Menu Lệnh Bot Aoyama",
            description="Chào mừng bạn! Hãy chọn một danh mục bên dưới để khám phá các tính năng của tôi.",
            color=discord.Color.purple()
        )
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        await ctx.send(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(Menu(bot))