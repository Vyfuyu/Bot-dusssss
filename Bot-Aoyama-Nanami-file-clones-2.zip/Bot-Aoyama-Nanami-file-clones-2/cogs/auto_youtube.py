# cogs/auto_youtube.py (Phiên bản nâng cấp: Chỉ lấy thông tin, không tải video)

import discord
from discord.ext import commands
import json
import os
import re
import asyncio
import yt_dlp
import functools

# --- CẤU HÌNH ---
DATA_FOLDER = "data"
YOUTUBE_CHANNELS_FILE = os.path.join(DATA_FOLDER, "youtube_auto_channels.json")

class AutoYoutube(commands.Cog):
    """Tự động phát hiện link YouTube và gửi thông tin chi tiết."""
    def __init__(self, bot):
        self.bot = bot
        self.active_channels = self.load_active_channels()
        # Regex được cải tiến để bắt được nhiều dạng link hơn
        self.youtube_regex = re.compile(
            r'(https?:\/\/(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|v\/)|youtu\.be\/)[\w-]{11}(?:\S+)?|https?:\/\/googleusercontent\.com\/youtube\.com\/\d+)'
        )

    def load_active_channels(self):
        if not os.path.exists(DATA_FOLDER): os.makedirs(DATA_FOLDER)
        if not os.path.exists(YOUTUBE_CHANNELS_FILE): return set()
        with open(YOUTUBE_CHANNELS_FILE, 'r') as f:
            try: return set(json.load(f))
            except json.JSONDecodeError: return set()

    def save_active_channels(self):
        with open(YOUTUBE_CHANNELS_FILE, 'w') as f:
            json.dump(list(self.active_channels), f)

    @commands.group(name="autoyt", help="Bật/tắt tính năng tự động phân tích link YouTube.")
    @commands.has_permissions(manage_channels=True)
    async def autoyt(self, ctx):
        if ctx.invoked_subcommand is None: await ctx.send_help(ctx.command)

    @autoyt.command(name="on", help="Bật tính năng trong kênh này.")
    async def autoyt_on(self, ctx):
        self.active_channels.add(ctx.channel.id)
        self.save_active_channels()
        await ctx.send(f"✅ Tính năng tự động phân tích link YouTube đã được **bật** cho kênh {ctx.channel.mention}.")

    @autoyt.command(name="off", help="Tắt tính năng trong kênh này.")
    async def autoyt_off(self, ctx):
        if ctx.channel.id in self.active_channels:
            self.active_channels.remove(ctx.channel.id)
            self.save_active_channels()
            await ctx.send(f"❌ Tính năng tự động phân tích link YouTube đã được **tắt** cho kênh {ctx.channel.mention}.")
        else: await ctx.send("Tính năng này vốn đã tắt trong kênh này.")

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or message.channel.id not in self.active_channels:
            return

        match = self.youtube_regex.search(message.content)
        if not match:
            return

        yt_url = match.group(0)

        async with message.channel.typing():
            try:
                # Chỉ lấy thông tin, không tải video
                ydl_opts = {'quiet': True, 'noplaylist': True, 'extract_flat': True}

                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(yt_url, download=False)

                if not info:
                    return await message.channel.send(f"Không thể lấy thông tin từ link: <{yt_url}>", suppress_embeds=True)

                # Tạo Embed đẹp mắt
                embed = discord.Embed(
                    title=info.get('title', 'Video từ YouTube'),
                    description=f"**Kênh:** {info.get('uploader', 'N/A')}",
                    url=info.get('webpage_url', yt_url),
                    color=discord.Color.red()
                )
                if info.get('thumbnail'):
                    embed.set_image(url=info.get('thumbnail'))

                # Chuyển đổi giây thành định dạng HH:MM:SS
                duration = int(info.get('duration', 0))
                hours, remainder = divmod(duration, 3600)
                minutes, seconds = divmod(remainder, 60)
                if hours > 0:
                    duration_str = f"{hours:02}:{minutes:02}:{seconds:02}"
                else:
                    duration_str = f"{minutes:02}:{seconds:02}"

                embed.add_field(name="Thời lượng ⏱️", value=duration_str, inline=True)
                embed.add_field(name="Lượt xem 👀", value=f"{info.get('view_count', 0):,}", inline=True)

                embed.set_footer(text=f"Link được chia sẻ bởi {message.author.display_name}")

                # Xóa tin nhắn gốc và gửi embed mới
                try: await message.delete()
                except: pass
                await message.channel.send(embed=embed)

            except Exception as e:
                # Gửi link gốc nếu có lỗi xảy ra
                await message.channel.send(f"Link YouTube từ {message.author.mention}: <{yt_url}>", suppress_embeds=True)
                print(f"Lỗi khi xử lý link YouTube: {e}")

async def setup(bot):
    await bot.add_cog(AutoYoutube(bot))