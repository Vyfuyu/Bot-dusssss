# cogs/general.py (Phiên bản nâng cấp với lệnh !status)

import discord
from discord.ext import commands
import random
import platform
import psutil
from datetime import datetime

class General(commands.Cog):
    """Các lệnh chung và kiểm tra thông tin bot."""
    def __init__(self, bot):
        self.bot = bot
        # Ghi lại thời điểm bot khởi động để tính uptime
        self.start_time = datetime.utcnow()

    @commands.command(name='ping', help='Kiểm tra độ trễ của bot.')
    async def ping(self, ctx):
        """Lệnh này trả về độ trễ của bot tới server Discord."""
        latency = round(self.bot.latency * 1000)  # Chuyển sang mili giây
        await ctx.send(f'Pong! Độ trễ là {latency}ms.')

    @commands.command(name='hello', help='Bot sẽ chào lại bạn.')
    async def hello(self, ctx):
        """Gửi lời chào thân thiện."""
        await ctx.send(f'Xin chào, {ctx.author.mention}!')

    # --- LỆNH MỚI: !STATUS ---
    @commands.command(name="status", aliases=['upt'], help="Kiểm tra trạng thái hoạt động của bot.")
    async def status(self, ctx):
        """Hiển thị các thông số chi tiết về bot và hệ thống."""

        # --- Lấy thông tin ---
        python_version = platform.python_version()
        discord_py_version = discord.__version__

        # Tính toán uptime
        uptime = datetime.utcnow() - self.start_time
        hours, remainder = divmod(int(uptime.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        days, hours = divmod(hours, 24)
        uptime_str = f"{days} ngày, {hours} giờ, {minutes} phút, {seconds} giây"

        # Lấy thông tin CPU và RAM
        cpu_usage = psutil.cpu_percent()
        ram_usage = psutil.virtual_memory()

        # --- Tạo Embed ---
        embed = discord.Embed(
            title="📊 Trạng thái của Aoyama Bot",
            description="Dưới đây là các thông số hoạt động hiện tại của bot.",
            color=discord.Color.blue()
        )
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)

        embed.add_field(name="📶 Ping", value=f"`{round(self.bot.latency * 1000)}ms`", inline=True)
        embed.add_field(name="⏰ Uptime", value=uptime_str, inline=False)

        embed.add_field(name="💻 CPU", value=f"`{cpu_usage}%`", inline=True)
        embed.add_field(
            name="🧠 RAM", 
            value=f"`{ram_usage.percent}%` ({ram_usage.used / (1024**3):.2f} GB / {ram_usage.total / (1024**3):.2f} GB)", 
            inline=True
        )

        embed.add_field(
            name="🌐 Hoạt động trên", 
            value=f"`{len(self.bot.guilds)}` server\n`{len(self.bot.users)}` người dùng", 
            inline=False
        )

        embed.add_field(
            name="🐍 Phiên bản", 
            value=f"**Python:** `{python_version}`\n**discord.py:** `{discord_py_version}`",
            inline=False
        )

        embed.timestamp = datetime.utcnow()
        embed.set_footer(text=f"Yêu cầu bởi {ctx.author.display_name}")

        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(General(bot))