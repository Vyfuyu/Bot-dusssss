# cogs/voice.py
# NÂNG CẤP: Gửi tin nhắn thoại (file .mp3) vào kênh chat

import discord
from discord.ext import commands
from gtts import gTTS
import os

# Tạo thư mục tạm để lưu file mp3 nếu chưa có
if not os.path.exists('audio_cache'):
    os.makedirs('audio_cache')

class VoiceFeatures(commands.Cog):
    """Các tính năng liên quan đến giọng nói và âm thanh."""
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="speak", aliases=['noi', 's'], help="Biến văn bản thành một tin nhắn thoại.")
    @commands.cooldown(1, 10, commands.BucketType.user) # Hạn chế spam
    async def speak(self, ctx, *, text: str):
        """Tạo một file mp3 từ văn bản và gửi vào kênh chat."""

        # Giới hạn độ dài văn bản để tránh tạo file quá lớn
        if len(text) > 500:
            return await ctx.send("❌ Văn bản quá dài! Vui lòng nhập dưới 500 ký tự.")

        processing_message = await ctx.send("🎙️ Đang tạo tin nhắn thoại...")

        filepath = f"audio_cache/{ctx.message.id}.mp3"

        # 1. Dùng gTTS để tạo file âm thanh
        try:
            # Chạy gTTS trong một luồng riêng để không làm treo bot
            # với các văn bản dài
            loop = self.bot.loop
            await loop.run_in_executor(None, self.create_gtts_file, text, filepath)

        except Exception as e:
            await processing_message.edit(content=f"❌ Lỗi khi tạo file âm thanh: {e}")
            return

        # 2. Gửi file mp3 đã tạo vào kênh chat
        try:
            # Kiểm tra xem file có thực sự được tạo ra không
            if os.path.exists(filepath):
                # Tạo một đối tượng discord.File từ đường dẫn file
                audio_file = discord.File(filepath)
                await ctx.send(f"Một tin nhắn thoại từ **{ctx.author.display_name}**:", file=audio_file)
                # Xóa tin nhắn "Đang tạo..."
                await processing_message.delete()
            else:
                await processing_message.edit(content="❌ Lỗi: Không thể tạo file âm thanh.")

        except Exception as e:
            await ctx.send(f"❌ Lỗi khi gửi file âm thanh: {e}")
        finally:
            # 3. Dọn dẹp: Xóa file tạm sau khi đã gửi
            if os.path.exists(filepath):
                os.remove(filepath)

    def create_gtts_file(self, text, filepath):
        """Hàm đồng bộ để chạy gTTS trong executor."""
        tts = gTTS(text=text, lang='vi', slow=False)
        tts.save(filepath)

    @speak.error
    async def speak_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"⏳ Lệnh đang trong thời gian hồi! Vui lòng thử lại sau **{error.retry_after:.1f}** giây.")
        else:
            await ctx.send(f"Đã có lỗi xảy ra với lệnh speak: {error}")


async def setup(bot):
    await bot.add_cog(VoiceFeatures(bot))