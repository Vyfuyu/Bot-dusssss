# cogs/news_fetcher.py

import discord
from discord.ext import commands
import os
import aiohttp
from urllib.parse import quote_plus # Dùng để mã hóa query cho URL
from googletrans import Translator

# --- VIEW ĐỂ LẬT TRANG TIN TỨC (ĐÃ NÂNG CẤP) ---
class NewsPaginatorView(discord.ui.View):
    def __init__(self, author: discord.User, articles: list, translator: Translator):
        super().__init__(timeout=300)
        self.author = author
        self.articles = articles
        self.translator = translator
        self.current_page = 0
        self.update_buttons()

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.author:
            await interaction.response.send_message("Đây không phải menu của bạn!", ephemeral=True)
            return False
        return True

    def create_embed(self):
        """Tạo Embed cho bài báo hiện tại, có kèm dịch thuật."""
        article = self.articles[self.current_page]

        # Lấy nội dung gốc
        original_title = article.get('title', 'Không có tiêu đề')
        original_description = article.get('description', 'Không có mô tả.') or "Không có mô tả."

        # --- TIẾN HÀNH DỊCH THUẬT ---
        try:
            # Dịch tiêu đề
            translated_title = self.translator.translate(original_title, src='en', dest='vi').text
            # Dịch mô tả
            translated_description = self.translator.translate(original_description, src='en', dest='vi').text
        except Exception as e:
            # Nếu dịch lỗi, dùng tạm nội dung gốc
            print(f"Lỗi dịch thuật: {e}")
            translated_title = f"(Lỗi dịch) {original_title}"
            translated_description = original_description

        embed = discord.Embed(
            title=translated_title, # <-- Dùng tiêu đề đã dịch
            description=translated_description, # <-- Dùng mô tả đã dịch
            url=article.get('url'),
            color=discord.Color.dark_blue()
        )
        if article.get('urlToImage'):
            embed.set_image(url=article.get('urlToImage'))

        source = article.get('source', {}).get('name', 'Không rõ nguồn')
        # Lấy và định dạng ngày đăng
        published_at_str = article.get('publishedAt', '')
        try:
            published_at_dt = datetime.fromisoformat(published_at_str.replace('Z', '+00:00'))
            published_at = published_at_dt.strftime('%d-%m-%Y')
        except:
            published_at = 'Không rõ'

        embed.add_field(name="Tiêu đề gốc (English)", value=original_title, inline=False)
        embed.set_footer(text=f"Nguồn: {source} | Ngày đăng: {published_at} | Bài {self.current_page + 1}/{len(self.articles)}")
        return embed

    def update_buttons(self):
        """Bật/tắt nút bấm dựa trên trang hiện tại."""
        # Nút "Trước" bị vô hiệu hóa ở trang đầu tiên
        self.children[0].disabled = self.current_page == 0
        # Nút "Sau" bị vô hiệu hóa ở trang cuối cùng
        self.children[1].disabled = self.current_page >= len(self.articles) - 1

    @discord.ui.button(label="⬅️ Trước", style=discord.ButtonStyle.secondary)
    async def previous_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current_page -= 1
        self.update_buttons()
        await interaction.response.edit_message(embed=self.create_embed(), view=self)

    @discord.ui.button(label="Sau ➡️", style=discord.ButtonStyle.primary)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current_page += 1
        self.update_buttons()
        await interaction.response.edit_message(embed=self.create_embed(), view=self)

class NewsFetcher(commands.Cog):
    """Tìm kiếm và hiển thị tin tức từ khắp nơi trên thế giới."""
    def __init__(self, bot):
        self.bot = bot
        self.api_key = os.environ.get("NEWS_API_KEY")
        self.session = aiohttp.ClientSession()
        self.translator = Translator() # Khởi tạo translator

    def cog_unload(self):
        if self.session:
            self.bot.loop.create_task(self.session.close())

    @commands.command(name="baochi", aliases=['news', 'tintuc'], help="Tìm kiếm tin tức về một chủ đề.")
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def get_news(self, ctx, *, query: str):
        if not self.api_key:
            return await ctx.send("❌ Tính năng tin tức chưa được cấu hình (thiếu API Key).")

        processing_message = await ctx.send(f"📰 Đang phân tích và dịch yêu cầu: \"_{query}_\"...")

        async with ctx.typing():
            # --- BƯỚC NÂNG CẤP: DỊCH YÊU CẦU TÌM KIẾM SANG TIẾNG ANH ---
            try:
                translated_query_obj = self.translator.translate(query, dest='en')
                english_query = translated_query_obj.text
            except Exception as e:
                return await processing_message.edit(content=f"❌ Lỗi khi dịch yêu cầu của bạn: {e}")
            # -----------------------------------------------------------------

            await processing_message.edit(content=f"📰 Đang tìm kiếm bằng tiếng Anh: \"_{english_query}_\"...")

            encoded_query = quote_plus(english_query) # Dùng query đã được dịch

            # Luôn tìm kiếm bằng tiếng Anh để có kết quả tốt nhất
            api_url = f"https://newsapi.org/v2/everything?q={encoded_query}&language=en&sortBy=publishedAt&pageSize=10&apiKey={self.api_key}"

            try:
                async with self.session.get(api_url) as response:
                    if response.status != 200:
                        return await processing_message.edit(content=f"❌ Lỗi khi kết nối đến NewsAPI (Mã: {response.status}).")
                    data = await response.json()

                if data.get("status") != "ok":
                    return await processing_message.edit(content=f"❌ Lỗi từ NewsAPI: {data.get('message')}")

                articles = data.get("articles", [])
                if not articles:
                    return await processing_message.edit(content=f"❌ Không tìm thấy bài báo nào cho chủ đề \"_{query}_\".")

                # Khởi tạo view lật trang và truyền translator vào
                view = NewsPaginatorView(ctx.author, articles, self.translator)
                initial_embed = view.create_embed()

                await processing_message.delete()
                await ctx.send(embed=initial_embed, view=view)
            except Exception as e:
                await processing_message.edit(content=f"❌ Đã có lỗi không mong muốn xảy ra: {e}")

    @get_news.error
    async def news_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"⏳ Bạn đang tìm kiếm quá nhanh! Vui lòng thử lại sau **{error.retry_after:.1f}** giây.")
        else:
            # Chuyển các lỗi khác cho hệ thống báo lỗi chung
            raise error

async def setup(bot):
    await bot.add_cog(NewsFetcher(bot))