# cogs/downloader.py

import discord
from discord.ext import commands
import yt_dlp
import os
import asyncio
import functools

# Tạo một thư mục để lưu file tạm thời
if not os.path.exists('downloads'):
    os.makedirs('downloads')

class Downloader(commands.Cog):
    """Tải video/audio từ nhiều nguồn bằng yt-dlp."""
    def __init__(self, bot):
        self.bot = bot

    def run_blocking_yt_dlp(self, ydl_opts, url):
        """Hàm chạy yt-dlp trong một luồng riêng để không làm treo bot."""
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            try:
                info = ydl.extract_info(url, download=True)
                return info
            except Exception as e:
                # Trả về lỗi để xử lý ở luồng chính
                return {'error': str(e)}

    @commands.command(name="download", aliases=['dl'], help="Tải video/audio. Định dạng: !dl <url> [mp3|video]")
    async def download(self, ctx, url: str, format_choice: str = 'video'):
        await ctx.send(f"Đang xử lý yêu cầu cho `{url}`... ⏳")
        async with ctx.typing():
            format_choice = format_choice.lower()

            # --- Bước 1: Lấy thông tin video mà không tải về ---
            try:
                # Chạy extract_info(download=False) trong executor để không block bot
                loop = asyncio.get_event_loop()
                info_opts = {'quiet': True, 'noplaylist': True}
                partial_info = functools.partial(yt_dlp.YoutubeDL(info_opts).extract_info, url, download=False)
                info = await loop.run_in_executor(None, partial_info)
            except Exception as e:
                return await ctx.send(f"❌ Lỗi khi lấy thông tin video: `{e}`")

            # --- Bước 2: Chọn định dạng và kiểm tra dung lượng ---
            file_size = 0
            if format_choice == 'mp3':
                # Tìm định dạng chỉ có audio tốt nhất
                selected_format = next((f for f in info['formats'] if f['acodec'] != 'none' and f['vcodec'] == 'none'), None)
            else: # video
                # Tìm định dạng video có cả hình và tiếng tốt nhất
                selected_format = next((f for f in info['formats'] if f.get('vcodec') != 'none' and f.get('acodec') != 'none'), info)

            if selected_format and selected_format.get('filesize'):
                file_size = selected_format.get('filesize')
            elif info.get('filesize'):
                file_size = info.get('filesize')
            else: # Ước tính nếu không có thông tin chính xác
                file_size = info.get('filesize_approx', 0)

            # Tạo embed thông tin
            embed = discord.Embed(title=info.get('title', 'Không có tiêu đề'), url=info.get('webpage_url'), color=discord.Color.red())
            embed.set_author(name=info.get('uploader', 'Không rõ tác giả'))
            duration = info.get('duration_string', 'N/A')
            embed.add_field(name="Thời lượng", value=duration, inline=True)

            # --- Bước 3: Quyết định tải về hay gửi link ---
            if file_size > ctx.guild.filesize_limit:
                embed.description = f"**⚠️ File quá lớn ({file_size / 1024 / 1024:.2f} MB) để tải lên!**\n[Nhấn vào đây để xem trên trang gốc]({info.get('webpage_url')})"
                return await ctx.send(embed=embed)

            await ctx.send(f"Đã lấy thông tin thành công, bắt đầu tải về (có thể mất một lúc)...")

            # --- Bước 4: Tải file về nếu dung lượng cho phép ---
            output_template = f'downloads/{info.get("id", "temp_video")}.%(ext)s'
            ydl_opts = {
                'quiet': True,
                'noplaylist': True,
                'outtmpl': output_template,
                # Chọn format cụ thể để tải, tránh tải file quá lớn không cần thiết
                'format': selected_format.get('format_id')
            }
            if format_choice == 'mp3':
                ydl_opts['postprocessors'] = [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '192',
                }]

            # Chạy hàm tải file blocking trong executor
            partial_download = functools.partial(self.run_blocking_yt_dlp, ydl_opts, url)
            download_info = await loop.run_in_executor(None, partial_download)

            if 'error' in download_info:
                return await ctx.send(f"❌ Lỗi trong quá trình tải về: `{download_info['error']}`")

            # Lấy đường dẫn file đã tải
            # yt-dlp sẽ tự đổi đuôi file thành mp3 nếu cần
            downloaded_file_path = ydl_opts['outtmpl'].replace('%(ext)s', 'mp3' if format_choice == 'mp3' else download_info.get('ext'))

            if not os.path.exists(downloaded_file_path):
                 # Đôi khi tên file cuối cùng khác một chút, tìm file mới nhất trong thư mục
                list_of_files = [os.path.join('downloads', f) for f in os.listdir('downloads')]
                downloaded_file_path = max(list_of_files, key=os.path.getctime) if list_of_files else None

            if downloaded_file_path and os.path.exists(downloaded_file_path):
                await ctx.send(f"✅ Tải về thành công! Đang gửi file lên...", embed=embed)
                await ctx.send(file=discord.File(downloaded_file_path))
                # Xóa file sau khi gửi để tiết kiệm dung lượng
                os.remove(downloaded_file_path)
            else:
                await ctx.send("❌ Đã có lỗi xảy ra, không tìm thấy file sau khi tải về.")

async def setup(bot):
    await bot.add_cog(Downloader(bot))