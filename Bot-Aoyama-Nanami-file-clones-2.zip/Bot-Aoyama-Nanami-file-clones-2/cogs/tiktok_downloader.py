# cogs/tiktok_downloader.py
# NÂNG CẤP: Thêm nút bấm "Tải MP3" vào mỗi video

import discord
from discord.ext import commands
import aiohttp
import io
import re
import json
import os

# --- CẤU HÌNH ---
DATA_FOLDER = "data"
TIKTOK_CHANNELS_FILE = os.path.join(DATA_FOLDER, "tiktok_auto_channels.json")

# --- VIEW MỚI VỚI NÚT BẤM TẢI MP3 ---
class TikTokActionView(discord.ui.View):
    def __init__(self, *, audio_url: str, video_title: str, timeout=300):
        super().__init__(timeout=timeout)
        self.audio_url = audio_url
        # Tạo tên file an toàn từ tiêu đề video
        self.filename = "".join(x for x in video_title if x.isalnum() or x in " _-").strip() or "tiktok_audio"
        self.session = aiohttp.ClientSession()

    async def on_timeout(self):
        # Vô hiệu hóa nút bấm khi hết thời gian
        for item in self.children:
            item.disabled = True
        # Cập nhật tin nhắn gốc để hiển thị nút bị vô hiệu hóa
        if self.message:
            await self.message.edit(view=self)

    @discord.ui.button(label="Tải MP3 🎵", style=discord.ButtonStyle.success)
    async def download_mp3_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Vô hiệu hóa nút ngay sau khi được nhấn để tránh spam
        button.disabled = True
        button.label = "Đang xử lý..."
        await interaction.response.edit_message(view=self)

        try:
            # Tải file âm thanh
            async with self.session.get(self.audio_url) as audio_response:
                if audio_response.status == 200:
                    audio_bytes = await audio_response.read()
                    mp3_file = discord.File(io.BytesIO(audio_bytes), filename=f"{self.filename}.mp3")
                    # Gửi file mp3 dưới dạng một tin nhắn mới
                    await interaction.followup.send(f"🎧 Đây là file MP3 cho **{interaction.user.mention}**:", file=mp3_file)
                else:
                    await interaction.followup.send("❌ Rất tiếc, không thể tải file âm thanh.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Đã có lỗi xảy ra: {e}", ephemeral=True)
        finally:
            # Đóng session sau khi dùng xong
            await self.session.close()
            self.stop() # Dừng view sau khi đã hoàn thành nhiệm vụ


class TikTokDownloader(commands.Cog):
    """Tải video TikTok theo yêu cầu, tự động và có tùy chọn tải MP3."""
    def __init__(self, bot):
        self.bot = bot
        self.session = aiohttp.ClientSession()
        self.active_channels = self.load_active_channels()
        self.tiktok_regex = re.compile(r'https?:\/\/(?:www\.|vm\.)?tiktok\.com\/[\w\-\.\/]+')

    def cog_unload(self):
        if self.session:
            self.bot.loop.create_task(self.session.close())

    def load_active_channels(self):
        if not os.path.exists(DATA_FOLDER): os.makedirs(DATA_FOLDER)
        if not os.path.exists(TIKTOK_CHANNELS_FILE): return set()
        with open(TIKTOK_CHANNELS_FILE, 'r') as f: return set(json.load(f))

    def save_active_channels(self):
        with open(TIKTOK_CHANNELS_FILE, 'w') as f: json.dump(list(self.active_channels), f)

    @commands.group(name="autott", help="Bật/tắt tính năng tự động tải video TikTok.")
    @commands.has_permissions(manage_channels=True)
    async def autott(self, ctx):
        if ctx.invoked_subcommand is None: await ctx.send_help(ctx.command)

    @autott.command(name="on", help="Bật tính năng tự động tải video trong kênh này.")
    async def autott_on(self, ctx):
        self.active_channels.add(ctx.channel.id); self.save_active_channels()
        await ctx.send(f"✅ Tính năng tự động tải TikTok đã được **bật** cho kênh {ctx.channel.mention}.")

    @autott.command(name="off", help="Tắt tính năng tự động tải video trong kênh này.")
    async def autott_off(self, ctx):
        if ctx.channel.id in self.active_channels:
            self.active_channels.remove(ctx.channel.id); self.save_active_channels()
            await ctx.send(f"❌ Tính năng tự động tải TikTok đã được **tắt** cho kênh {ctx.channel.mention}.")
        else: await ctx.send("Tính năng này vốn đã tắt trong kênh này.")

    async def process_tiktok_link(self, url, channel, requested_by_user):
        """Hàm chung để xử lý một link TikTok và gửi kèm nút bấm."""
        async with channel.typing():
            try:
                api_url = f"https://www.tikwm.com/api/?url={url}"
                async with self.session.get(api_url) as response:
                    if response.status != 200: return
                    data = await response.json()
                if data.get('code') != 0: return

                video_data = data.get('data', {})
                video_url = video_data.get('play')
                audio_url = video_data.get('music') # Lấy link âm thanh
                video_title = video_data.get('title', 'tiktok_video')

                if not video_url: return

                async with self.session.get(video_url) as video_response:
                    video_bytes = await video_response.read()

                author_info = video_data.get('author', {})
                embed = discord.Embed(title=video_title, color=discord.Color.from_rgb(238, 29, 82))
                embed.set_author(name=f"@{author_info.get('unique_id', '...')}", icon_url=author_info.get('avatar'))
                embed.add_field(name="❤️", value=f"{video_data.get('digg_count', 0):,}")
                embed.add_field(name="💬", value=f"{video_data.get('comment_count', 0):,}")
                embed.add_field(name="🔗", value=f"{video_data.get('share_count', 0):,}")
                embed.set_footer(text=f"Yêu cầu bởi {requested_by_user.display_name}")

                # Tạo View với nút bấm nếu có link audio
                view = discord.ui.View()
                if audio_url:
                    view = TikTokActionView(audio_url=audio_url, video_title=video_title)

                if len(video_bytes) > channel.guild.filesize_limit:
                    embed.description = f"**Video quá lớn!**\n[Nhấn vào đây để tải]({video_url})"
                    sent_message = await channel.send(embed=embed, view=view)
                else:
                    video_file = discord.File(io.BytesIO(video_bytes), filename="tiktok.mp4")
                    sent_message = await channel.send(embed=embed, file=video_file, view=view)

                # Gán message vào view để có thể edit khi timeout
                if isinstance(view, TikTokActionView):
                    view.message = sent_message

            except Exception as e:
                print(f"Lỗi khi xử lý TikTok link {url}: {e}")

    @commands.command(name="tiktok", aliases=['ttdl'], help="Tải video TikTok bằng link.")
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def download_tiktok_command(self, ctx, *, tiktok_url: str):
        try: await ctx.message.delete()
        except: pass
        await self.process_tiktok_link(tiktok_url, ctx.channel, ctx.author)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or message.channel.id not in self.active_channels: return
        match = self.tiktok_regex.search(message.content)
        if not match: return
        tiktok_url = match.group(0)
        try: await message.delete()
        except: pass
        await self.process_tiktok_link(tiktok_url, message.channel, message.author)

async def setup(bot):
    await bot.add_cog(TikTokDownloader(bot))