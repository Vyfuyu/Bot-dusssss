# cogs/error_handler.py
# Phiên bản Giám sát Toàn diện: Log mọi hoạt động và lỗi ra console

import discord
from discord.ext import commands
import json
import os
import traceback
from datetime import datetime
import sys

# --- CẤU HÌNH ---
DATA_FOLDER = "data"
PERMISSIONS_FILE = os.path.join(DATA_FOLDER, "permissions_data.json")

def get_admin_ids(bot):
    """Hàm phụ an toàn để lấy danh sách ID của Owner và các Bot Admin."""
    owner_id = None
    try:
        owner_id = bot.owner_id or bot.application.owner.id
    except AttributeError:
        # Bot chưa sẵn sàng, trả về set rỗng
        return set()

    admin_ids = []
    if os.path.exists(PERMISSIONS_FILE):
        with open(PERMISSIONS_FILE, 'r', encoding='utf-8') as f:
            try:
                data = json.load(f)
                admin_ids = data.get("bot_admins", [])
            except json.JSONDecodeError:
                pass

    # Đảm bảo owner_id không rỗng trước khi thêm
    if owner_id:
        return set(admin_ids + [owner_id])
    return set(admin_ids)

class ErrorHandler(commands.Cog):
    """Cog chuyên xử lý, log và báo cáo lỗi trên toàn bot."""
    def __init__(self, bot):
        self.bot = bot

    # --- Listener mới: Ghi log khi lệnh được gọi ---
    @commands.Cog.listener()
    async def on_command(self, ctx: commands.Context):
        """Sự kiện được kích hoạt mỗi khi một lệnh được bắt đầu."""
        guild_name = ctx.guild.name if ctx.guild else "Tin nhắn riêng (DM)"
        print(f"[COMMAND] User '{ctx.author}' ({ctx.author.id}) ran command: '{ctx.message.content}' in guild '{guild_name}' ({ctx.guild.id})")

    # --- Listener mới: Ghi log khi lệnh hoàn thành ---
    @commands.Cog.listener()
    async def on_command_completion(self, ctx: commands.Context):
        """Sự kiện được kích hoạt mỗi khi một lệnh chạy thành công."""
        print(f"[SUCCESS] Command '{ctx.command.name}' finished successfully.")


    # --- Listener on_command_error đã được nâng cấp ---
    @commands.Cog.listener()
    async def on_command_error(self, ctx: commands.Context, error: commands.CommandError):
        """
        Trình xử lý lỗi toàn cục. Giờ đây sẽ in TẤT CẢ lỗi ra console.
        """
        # In lỗi ra console để debug, bất kể là lỗi gì
        print("\n" + "="*50, file=sys.stderr)
        print(f"An error occurred in command: {ctx.command}", file=sys.stderr)
        print(f"Invoked by: {ctx.author} ({ctx.author.id})", file=sys.stderr)
        print(f"Message: {ctx.message.content}", file=sys.stderr)
        print(f"Error Type: {type(error)}", file=sys.stderr)
        traceback.print_exception(type(error), error, error.__traceback__, file=sys.stderr)
        print("="*50 + "\n", file=sys.stderr)

        # --- Logic cũ để gửi tin nhắn vẫn giữ nguyên ---
        # 1. Bỏ qua nếu lệnh đã có trình xử lý lỗi riêng
        if hasattr(ctx.command, 'on_error'):
            return

        # 2. Bỏ qua các lỗi người dùng thường gặp, không cần thông báo công khai
        ignored_errors = (commands.CommandNotFound, commands.CheckFailure, commands.CommandOnCooldown)
        if isinstance(error, ignored_errors):
            return # Im lặng bỏ qua, vì lỗi đã được in ra console rồi

        # 3. Với các lỗi nghiêm trọng khác, gửi báo cáo
        tb_str = "".join(traceback.format_exception(type(error), error, error.__traceback__))
        embed = discord.Embed(
            title="🚨 Báo Cáo Lỗi Tự Động 🚨",
            description=f"Một lỗi đã xảy ra ở kênh {ctx.channel.mention}",
            color=discord.Color.dark_red(),
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="Người dùng", value=f"{ctx.author.mention} (`{ctx.author.id}`)", inline=False)
        embed.add_field(name="Lệnh", value=f"`{ctx.message.content}`", inline=False)
        log_to_send = f"```python\n{tb_str[:3500]}\n```"
        embed.add_field(name="Traceback Chi Tiết", value=log_to_send, inline=False)

        # Gửi báo cáo lỗi đến kênh log đã thiết lập
        log_channel_id = self.get_log_channel_id_from_guild(ctx.guild.id) if ctx.guild else None
        if log_channel_id:
            log_channel = self.bot.get_channel(log_channel_id)
            if log_channel:
                try:
                    await log_channel.send(embed=embed)
                except Exception as e:
                    print(f"Lỗi nghiêm trọng: Không thể gửi báo cáo lỗi vào kênh log {log_channel_id}. Lỗi: {e}")

        await ctx.send("Rất tiếc, đã có một lỗi không mong muốn xảy ra. Đội ngũ admin đã được thông báo. 😢")

    def get_log_channel_id_from_guild(self, guild_id):
        """Hàm phụ để đọc file và lấy ID của kênh log."""
        if not os.path.exists(PERMISSIONS_FILE): return None
        with open(PERMISSIONS_FILE, 'r', encoding='utf-8') as f:
            try:
                data = json.load(f)
                guild_config = data.get(str(guild_id), {})
                return guild_config.get("error_log_channel")
            except json.JSONDecodeError:
                return None

async def setup(bot):
    await bot.add_cog(ErrorHandler(bot))