# cogs/welcome.py

import discord
from discord.ext import commands
import json
import os

# --- CẤU HÌNH ---
DATA_FOLDER = "data"
WELCOME_CONFIG_FILE = os.path.join(DATA_FOLDER, "welcome_config.json")

class Welcome(commands.Cog):
    """Hệ thống tự động chào mừng và tạm biệt thành viên."""
    def __init__(self, bot):
        self.bot = bot
        self.config = self.load_config()

    # --- HÀM QUẢN LÝ CẤU HÌNH ---
    def load_config(self):
        if not os.path.exists(DATA_FOLDER): os.makedirs(DATA_FOLDER)
        if not os.path.exists(WELCOME_CONFIG_FILE): return {}
        try:
            with open(WELCOME_CONFIG_FILE, 'r', encoding='utf-8') as f: return json.load(f)
        except json.JSONDecodeError: return {}

    def save_config(self):
        with open(WELCOME_CONFIG_FILE, 'w') as f:
            json.dump(self.config, f, indent=4)

    def get_guild_config(self, guild_id):
        """Lấy hoặc tạo mới entry cho server."""
        guild_id_str = str(guild_id)
        if guild_id_str not in self.config:
            self.config[guild_id_str] = {
                "channel_id": None,
                "welcome_message": "Chào mừng {user.mention} đã đến với **{server.name}**! Bạn là thành viên thứ **{member_count}**.",
                "leave_message": "**{user.name}** đã rời khỏi server. Tạm biệt!",
                "image_url": None
            }
        return self.config[guild_id_str]

    # --- LỆNH NHÓM !WELCOME ---
    @commands.group(name="welcome", invoke_without_command=True, help="[ADMIN] Cài đặt hệ thống chào mừng.")
    @commands.has_permissions(manage_guild=True) # Yêu cầu quyền "Quản lý Server"
    async def welcome(self, ctx):
        await ctx.send_help(ctx.command)

    @welcome.command(name="set", help="Thiết lập kênh để gửi tin nhắn chào mừng.")
    async def welcome_set(self, ctx, channel: discord.TextChannel):
        guild_config = self.get_guild_config(ctx.guild.id)
        guild_config["channel_id"] = channel.id
        self.save_config()
        await ctx.send(f"✅ Đã thiết lập kênh chào mừng là {channel.mention}.")

    @welcome.command(name="off", help="Tắt hệ thống chào mừng.")
    async def welcome_off(self, ctx):
        guild_id_str = str(ctx.guild.id)
        if guild_id_str in self.config:
            # Thay vì xóa, chỉ cần đặt channel_id thành None để vô hiệu hóa
            self.config[guild_id_str]["channel_id"] = None
            self.save_config()
            await ctx.send("✅ Hệ thống chào mừng đã được tắt. Các cấu hình tin nhắn và ảnh vẫn được giữ lại.")
        else:
            await ctx.send("❌ Hệ thống chào mừng vốn đã tắt.")

    @welcome.command(name="message", help="Tùy chỉnh nội dung tin nhắn chào mừng.")
    async def welcome_message(self, ctx, *, message: str):
        guild_config = self.get_guild_config(ctx.guild.id)
        guild_config["welcome_message"] = message
        self.save_config()
        await ctx.send(f"✅ Đã cập nhật tin nhắn chào mừng. Dùng `!welcome test` để xem thử.")
        await ctx.send(f"💡 **Các biến có thể dùng:** `{{user.mention}}`, `{{user.name}}`, `{{server.name}}`, `{{member_count}}`")

    @welcome.command(name="image", help="Đặt ảnh/GIF cho tin nhắn chào mừng.")
    async def welcome_image(self, ctx, url: str = None):
        guild_config = self.get_guild_config(ctx.guild.id)
        guild_config["image_url"] = url
        self.save_config()
        if url:
            await ctx.send(f"✅ Đã cập nhật ảnh chào mừng. Dùng `!welcome test` để xem thử.")
        else:
            await ctx.send(f"✅ Đã xóa ảnh chào mừng.")


    @welcome.command(name="test", help="Gửi một tin nhắn chào mừng thử nghiệm.")
    async def welcome_test(self, ctx):
        guild_config = self.get_guild_config(ctx.guild.id)
        channel_id = guild_config.get("channel_id")
        if not channel_id:
            return await ctx.send("❌ Vui lòng thiết lập kênh chào mừng trước bằng lệnh `!welcome set #tên-kênh`.")

        channel = self.bot.get_channel(channel_id)
        if not channel:
            return await ctx.send(f"❌ Không tìm thấy kênh đã thiết lập. Có thể nó đã bị xóa. Vui lòng dùng `!welcome set` lại.")

        # Gửi tin nhắn chào mừng giả lập với chính người dùng đã gõ lệnh
        await self.send_welcome_message(ctx.author)
        await ctx.send(f"✅ Đã gửi một tin nhắn thử nghiệm đến kênh {channel.mention}.")

    # --- HÀM HELPER ĐỂ GỬI TIN NHẮN (ĐÃ SỬA LỖI) ---
    async def send_welcome_message(self, member):
        guild_config = self.get_guild_config(member.guild.id)
        channel_id = guild_config.get("channel_id")
        if not channel_id: return

        channel = self.bot.get_channel(channel_id)
        if not channel: return

        # Thay thế các biến trong tin nhắn
        message_format = guild_config.get("welcome_message", "Chào mừng {user.mention}!")
        # Cung cấp trực tiếp đối tượng 'user' và 'server' để format
        message = message_format.format(
            user=member,
            server=member.guild,
            member_count=member.guild.member_count
        )

        embed = discord.Embed(
            title="✨ CHÀO MỪNG THÀNH VIÊN MỚI ✨",
            description=message,
            color=discord.Color.green()
        )
        embed.set_thumbnail(url=member.display_avatar.url)

        image_url = guild_config.get("image_url")
        if image_url:
            embed.set_image(url=image_url)

        # Tag người dùng ở ngoài embed để họ nhận được thông báo
        await channel.send(content=member.mention, embed=embed)

    # --- CÁC SỰ KIỆN LISTENER ---
    @commands.Cog.listener()
    async def on_member_join(self, member):
        # Gọi hàm gửi tin nhắn chào mừng khi có người mới vào
        await self.send_welcome_message(member)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        guild_config = self.get_guild_config(member.guild.id)
        channel_id = guild_config.get("channel_id")
        if not channel_id: return

        channel = self.bot.get_channel(channel_id)
        if not channel: return

        # Thay thế biến trong tin nhắn tạm biệt
        message_format = guild_config.get("leave_message", "**{user.name}** đã rời khỏi server. Tạm biệt!").format(
            user=member,
            server=member.guild
        )

        embed = discord.Embed(
            title="👋 THÀNH VIÊN ĐÃ RỜI ĐI 👋",
            description=message_format,
            color=discord.Color.dark_grey()
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        await channel.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Welcome(bot))