# cogs/aoyama_ai.py

import discord
from discord.ext import commands
import json
import os

# Import hàm check quyền admin từ cog Admin
from .admin import is_bot_admin

# --- CẤU HÌNH AOYAMA AI ---
DATA_FOLDER = "data"
AOYAMA_BRAIN_FILE = os.path.join(DATA_FOLDER, "aoyama_brain.json")

class AoyamaAI(commands.Cog):
    """Một chatbot tùy chỉnh có thể học hỏi và được huấn luyện."""
    def __init__(self, bot):
        self.bot = bot
        self.brain = self.load_brain()
        self.active_channels = set()

    # --- HÀM QUẢN LÝ "BỘ NÃO" ---
    def load_brain(self):
        if not os.path.exists(DATA_FOLDER):
            os.makedirs(DATA_FOLDER)
        if not os.path.exists(AOYAMA_BRAIN_FILE):
            return {}
        try:
            with open(AOYAMA_BRAIN_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {}

    def save_brain(self):
        with open(AOYAMA_BRAIN_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.brain, f, indent=4, ensure_ascii=False)

    # --- LỆNH NHÓM !AOYAMA ---
    @commands.group(name="aoyama", invoke_without_command=True, help="Hệ thống AI Aoyama tùy chỉnh.")
    async def aoyama(self, ctx):
        await ctx.send_help(ctx.command)

    @aoyama.command(name="on", help="Bật Aoyama AI trong kênh này.")
    @commands.has_permissions(manage_channels=True)
    async def aoyama_on(self, ctx):
        self.active_channels.add(ctx.channel.id)
        await ctx.send(f"🤖 **Aoyama AI** đã được bật trong kênh {ctx.channel.mention}.")

    @aoyama.command(name="off", help="Tắt Aoyama AI trong kênh này.")
    @commands.has_permissions(manage_channels=True)
    async def aoyama_off(self, ctx):
        if ctx.channel.id in self.active_channels:
            self.active_channels.remove(ctx.channel.id)
            await ctx.send(f"😴 **Aoyama AI** đã được tắt trong kênh {ctx.channel.mention}.")
        else:
            await ctx.send("AI vốn đã tắt trong kênh này rồi.")

    @aoyama.command(name="seed", aliases=['dạy'], help="Dạy cho Aoyama AI. Dùng '|' để ngăn cách.")
    @is_bot_admin() # Chỉ admin mới được dạy để tránh spam
    async def seed(self, ctx, *, full_text: str):
        """Dạy cho bot. Cú pháp: !aoyama seed <từ khóa> | <câu trả lời>"""
        if '|' not in full_text:
            return await ctx.send("❌ Sai cú pháp! Vui lòng dùng dấu `|` để ngăn cách giữa từ khóa và câu trả lời.")

        parts = full_text.split('|', 1)
        trigger = parts[0].strip().lower() # Chuyển từ khóa về chữ thường để dễ bắt
        response = parts[1].strip()

        if not trigger or not response:
            return await ctx.send("❌ Từ khóa và câu trả lời không được để trống.")

        self.brain[trigger] = response
        self.save_brain()

        embed = discord.Embed(title="🧠 Tiếp thu kiến thức mới!", color=discord.Color.teal())
        embed.add_field(name="Khi nghe thấy", value=f"`{trigger}`", inline=False)
        embed.add_field(name="Sẽ đáp lại", value=f"`{response}`", inline=False)
        await ctx.send(embed=embed)

    @aoyama.command(name="forget", aliases=['xóa'], help="[ADMIN] Xóa một từ khóa đã dạy.")
    @is_bot_admin()
    async def forget(self, ctx, *, trigger_to_forget: str):
        trigger = trigger_to_forget.strip().lower()
        if trigger in self.brain:
            del self.brain[trigger]
            self.save_brain()
            await ctx.send(f"✅ Đã xóa thành công từ khóa `{trigger}` khỏi bộ nhớ.")
        else:
            await ctx.send(f"❌ Không tìm thấy từ khóa `{trigger}` trong bộ nhớ.")

    @aoyama.command(name="list", help="Xem danh sách các câu đã dạy.")
    async def list_learned(self, ctx):
        if not self.brain:
            return await ctx.send("Bộ não của tôi vẫn còn trống trơn...")

        embed = discord.Embed(title="📖 Những điều Aoyama AI đã học", color=discord.Color.blue())
        description = ""
        for trigger, response in self.brain.items():
            description += f"**Khi nghe:** `{trigger}`\n**Sẽ đáp:** `{response}`\n\n"

        # Giới hạn để không quá dài
        if len(description) > 4000:
            description = description[:4000] + "\n..."

        embed.description = description
        await ctx.send(embed=embed)

    # --- HÀM LẮNG NGHE VÀ TỰ ĐỘNG TRẢ LỜI ---
    @commands.Cog.listener()
    async def on_message(self, message):
        # Bỏ qua tin nhắn từ bot và các lệnh
        if message.author.bot or message.content.startswith(self.bot.command_prefix):
            return

        # Chỉ hoạt động trong các kênh đã được bật
        if message.channel.id not in self.active_channels:
            return

        message_content_lower = message.content.lower()

        # Lặp qua tất cả các từ khóa đã học
        for trigger, response in self.brain.items():
            # Nếu tin nhắn chứa từ khóa
            if trigger in message_content_lower:
                # Gửi câu trả lời và dừng lại để tránh spam
                await message.channel.send(response)
                return

async def setup(bot):
    await bot.add_cog(AoyamaAI(bot))