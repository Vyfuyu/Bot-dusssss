# cogs/image_generator.py

import discord
from discord.ext import commands
import os
import aiohttp
import base64
import io
from googletrans import Translator # <-- Thêm thư viện dịch

class ImageGenerator(commands.Cog):
    """Tạo ảnh từ văn bản bằng AI của Stability AI."""
    def __init__(self, bot):
        self.bot = bot
        self.api_key = os.environ.get("STABILITY_API_KEY")
        self.api_host = "https://api.stability.ai"
        self.engine_id = "stable-diffusion-v1-6" 
        self.session = aiohttp.ClientSession()
        # Khởi tạo translator
        self.translator = Translator()

    def cog_unload(self):
        if self.session:
            self.bot.loop.create_task(self.session.close())

    @commands.command(name="imagine", aliases=['createimage', 'vẽ'], help="Tạo ảnh từ mô tả của bạn.")
    @commands.cooldown(1, 30, commands.BucketType.user)
    async def imagine(self, ctx, *, prompt: str):
        if not self.api_key:
            return await ctx.send("❌ Tính năng tạo ảnh chưa được cấu hình (thiếu API Key).")

        processing_message = await ctx.send(f"🎨 Đang phân tích ý tưởng: \"_{prompt}_\"...")

        async with ctx.typing():
            try:
                # --- BƯỚC DỊCH THUẬT TỰ ĐỘNG ---
                try:
                    translated = self.translator.translate(prompt, src='vi', dest='en')
                    english_prompt = translated.text
                    await processing_message.edit(content=f"🎨 Đã dịch ý tưởng, đang phác họa: \"_{english_prompt}_\"...")
                except Exception as e:
                    await processing_message.edit(content=f"❌ Lỗi dịch thuật: {e}")
                    return
                # ------------------------------------

                api_url = f"{self.api_host}/v1/generation/{self.engine_id}/text-to-image"

                headers = {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self.api_key}"
                }

                payload = {
                    "text_prompts": [
                        {
                            "text": english_prompt # <-- Gửi đi prompt tiếng Anh
                        }
                    ],
                    "cfg_scale": 7, "height": 512, "width": 512,
                    "samples": 1, "steps": 30,
                }

                async with self.session.post(api_url, headers=headers, json=payload) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        await processing_message.edit(content=f"❌ Lỗi từ Stability AI: `{error_text}`")
                        return

                    data = await response.json()

                    image_data = data["artifacts"][0]
                    if image_data.get("finishReason") == "CONTENT_FILTERED":
                         await processing_message.edit(content="❌ Nội dung của bạn đã bị bộ lọc của AI từ chối vì không phù hợp.")
                         return

                    image_bytes = base64.b64decode(image_data["base64"])
                    image_file = discord.File(io.BytesIO(image_bytes), filename="generated_image.png")

                    embed = discord.Embed(
                        title="✨ Tác phẩm hoàn thành!",
                        description=f"**Nội dung gốc:** \"_{prompt}_\"",
                        color=discord.Color.magenta()
                    )
                    embed.add_field(name="Đã dịch sang tiếng Anh", value=f"_{english_prompt}_")
                    embed.set_image(url="attachment://generated_image.png")
                    embed.set_footer(text=f"Yêu cầu bởi {ctx.author.display_name}")

                    await processing_message.delete()
                    await ctx.send(embed=embed, file=image_file)

            except Exception as e:
                await processing_message.edit(content=f"❌ Đã có lỗi không mong muốn xảy ra: {e}")

    @imagine.error
    async def imagine_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"⏳ Bạn đang trong thời gian chờ! Vui lòng thử lại sau **{error.retry_after:.2f}** giây.")

async def setup(bot):
    await bot.add_cog(ImageGenerator(bot))