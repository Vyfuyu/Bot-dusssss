# cogs/economy.py (Phiên bản nâng cấp lệnh setcoin và thêm topcoin)

import discord
from discord.ext import commands
import json
import os
import random
from datetime import datetime, timedelta

# Import hàm check quyền từ cog Admin
try:
    from .admin import is_bot_support
except ImportError:
    # Fallback nếu cog admin không tồn tại hoặc có lỗi
    def is_bot_support():
        return commands.is_owner()

# --- CẤU HÌNH KINH TẾ ---
DATA_FOLDER = "data"
USER_DATA_FILE = os.path.join(DATA_FOLDER, "economy_data.json")
STARTING_COINS = 100
WORK_COOLDOWN_SECONDS = 3600 # 1 giờ
WORK_REWARD_MIN = 50
WORK_REWARD_MAX = 200

class Economy(commands.Cog):
    """Quản lý tiền tệ Aoyama Coin và các lệnh liên quan."""
    def __init__(self, bot):
        self.bot = bot
        self.user_data = self.load_user_data()

    # --- HÀM QUẢN LÝ DỮ LIỆU (DATABASE) ---
    def load_user_data(self):
        if not os.path.exists(DATA_FOLDER): os.makedirs(DATA_FOLDER)
        if not os.path.exists(USER_DATA_FILE): return {}
        try:
            with open(USER_DATA_FILE, 'r', encoding='utf-8') as f: return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError): return {}

    def save_user_data(self):
        with open(USER_DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.user_data, f, indent=4, ensure_ascii=False)

    def get_user_entry(self, user_id):
        user_id_str = str(user_id)
        if user_id_str not in self.user_data:
            self.user_data[user_id_str] = {
                "balance": STARTING_COINS,
                "last_work": None
            }
        return self.user_data[user_id_str]

    # --- HÀM CÔNG KHAI ---
    def get_balance(self, user_id):
        entry = self.get_user_entry(user_id)
        return entry.get("balance", 0)

    def add_balance(self, user_id, amount):
        entry = self.get_user_entry(user_id)
        entry["balance"] = self.get_balance(user_id) + amount
        self.save_user_data()

    def remove_balance(self, user_id, amount):
        current_balance = self.get_balance(user_id)
        if current_balance < amount: return False
        entry = self.get_user_entry(user_id)
        entry["balance"] = current_balance - amount
        self.save_user_data()
        return True

    def set_user_balance(self, user_id, amount):
        entry = self.get_user_entry(user_id)
        entry["balance"] = amount
        self.save_user_data()

    # --- CÁC LỆNH CHO NGƯỜI DÙNG ---

    @commands.command(name="coin", aliases=['balance', 'ví'], help="Kiểm tra số dư Aoyama Coin của bạn.")
    async def balance_check(self, ctx, member: discord.Member = None):
        target_user = member or ctx.author
        balance = self.get_balance(target_user.id)
        embed = discord.Embed(
            title=f"🪙 Ví Aoyama Coin của {target_user.display_name}",
            description=f"Số dư hiện tại: **{balance:,}** Aoyama Coin",
            color=discord.Color.gold()
        )
        await ctx.send(embed=embed)

    @commands.command(name="làmviệc", aliases=['work'], help="Làm việc chăm chỉ để kiếm Aoyama Coin.")
    async def work(self, ctx):
        user_entry = self.get_user_entry(ctx.author.id)
        now = datetime.now()
        if user_entry.get("last_work"):
            last_work_time = datetime.fromisoformat(user_entry["last_work"])
            if now < last_work_time + timedelta(seconds=WORK_COOLDOWN_SECONDS):
                time_left = last_work_time + timedelta(seconds=WORK_COOLDOWN_SECONDS) - now
                minutes_left = int(time_left.total_seconds() / 60)
                return await ctx.send(f"🧘 Bạn vừa mới làm việc xong! Thử lại sau **{minutes_left}** phút.")
        reward = random.randint(WORK_REWARD_MIN, WORK_REWARD_MAX)
        self.add_balance(ctx.author.id, reward)
        user_entry["last_work"] = now.isoformat()
        self.save_user_data()
        await ctx.send(f"✅ {ctx.author.display_name} chăm chỉ làm việc và nhận được **{reward:,}** Aoyama Coin! 💰")

    @commands.command(name="chuyển", aliases=['pay'], help="Chuyển Aoyama Coin cho người khác.")
    async def pay(self, ctx, receiver: discord.Member, amount: int):
        sender_id = ctx.author.id
        if sender_id == receiver.id: return await ctx.send("❌ Bạn không thể tự chuyển tiền cho chính mình!")
        if amount <= 0: return await ctx.send("❌ Số tiền chuyển phải là một số dương!")
        if self.get_balance(sender_id) < amount: return await ctx.send(f"❌ Bạn không đủ tiền!")
        self.remove_balance(sender_id, amount)
        self.add_balance(receiver.id, amount)
        await ctx.send(f"✅ Giao dịch thành công! **{ctx.author.display_name}** đã chuyển **{amount:,}** Aoyama Coin cho **{receiver.display_name}**.")

    # --- LỆNH BẢNG XẾP HẠNG MỚI ---
    @commands.command(name="topcoin", aliases=['topc', 'bxhcoin'], help="Xem bảng xếp hạng các đại gia Aoyama Coin.")
    @commands.cooldown(1, 20, commands.BucketType.user)
    async def top_coin(self, ctx):
        # Lấy dữ liệu và kiểm tra xem có rỗng không
        if not self.user_data:
            return await ctx.send("Bảng xếp hạng hiện đang trống!")

        # Sắp xếp người dùng dựa trên số dư, từ cao đến thấp
        sorted_users = sorted(
            self.user_data.items(), 
            key=lambda item: item[1].get('balance', 0), 
            reverse=True
        )

        embed = discord.Embed(
            title="🏆 Bảng Xếp Hạng Đại Gia Aoyama Coin 🏆",
            description="Top 10 người dùng giàu có nhất server!",
            color=discord.Color.from_rgb(255, 215, 0) # Màu vàng Gold
        )

        # Lấy top 10 hoặc ít hơn nếu không đủ
        rank_list = ""
        for i, (user_id, data) in enumerate(sorted_users[:10]):
            rank = i + 1
            try:
                user = await self.bot.fetch_user(int(user_id))
                user_name = user.display_name
            except (discord.NotFound, ValueError):
                user_name = f"Người dùng ID: {user_id[-4:]}" # Hiển thị 4 số cuối ID nếu không tìm thấy

            balance = data.get('balance', 0)

            # Thêm emoji cho top 3
            if rank == 1: rank_emoji = "🥇"
            elif rank == 2: rank_emoji = "🥈"
            elif rank == 3: rank_emoji = "🥉"
            else: rank_emoji = f"**#{rank}**"

            rank_list += f"{rank_emoji} {user_name}: **{balance:,}** Aoyama Coin 🪙\n"

        if not rank_list:
            embed.description = "Chưa có ai trên bảng xếp hạng."
        else:
            embed.description = rank_list

        await ctx.send(embed=embed)

    # --- LỆNH NHÓM ADMIN ---
    @commands.group(name="setcoin", invoke_without_command=True, help="[SUPPORT] Các lệnh quản lý tiền tệ.")
    @is_bot_support()
    async def setcoin(self, ctx):
        await ctx.send_help(ctx.command)

    @setcoin.command(name="add", help="Cộng tiền cho một thành viên.")
    async def setcoin_add(self, ctx, amount: int, member: discord.Member):
        if amount <= 0: return await ctx.send("❌ Số tiền cộng vào phải dương!")
        self.add_balance(member.id, amount)
        new_balance = self.get_balance(member.id)
        await ctx.send(f"✅ Đã cộng **{amount:,}** Aoyama Coin cho **{member.display_name}**. Số dư mới: **{new_balance:,}** 🪙.")

    @setcoin.command(name="remove", aliases=['sub'], help="Trừ tiền của một thành viên.")
    async def setcoin_remove(self, ctx, amount: int, member: discord.Member):
        if amount <= 0: return await ctx.send("❌ Số tiền trừ đi phải dương!")
        if not self.remove_balance(member.id, amount):
            return await ctx.send(f"❌ Không thể trừ tiền! Số dư của **{member.display_name}** không đủ.")
        new_balance = self.get_balance(member.id)
        await ctx.send(f"✅ Đã trừ **{amount:,}** Aoyama Coin của **{member.display_name}**. Số dư mới: **{new_balance:,}** 🪙.")

    @setcoin.command(name="set", help="Thiết lập lại số tiền chính xác cho một thành viên.")
    async def setcoin_set(self, ctx, amount: int, member: discord.Member):
        if amount < 0: return await ctx.send("❌ Không thể đặt số tiền âm!")
        self.set_user_balance(member.id, amount)
        await ctx.send(f"✅ Đã đặt lại số dư của **{member.display_name}** thành **{amount:,}** Aoyama Coin.")

async def setup(bot):
    await bot.add_cog(Economy(bot))