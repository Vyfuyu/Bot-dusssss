# cogs/test.py

import discord
from discord.ext import commands

# Import hàm check quyền admin từ cog Admin để tái sử dụng
# Điều này cho phép chúng ta bảo vệ lệnh test mà không cần viết lại logic check quyền
from .admin import is_bot_admin

class TestCommands(commands.Cog):
    """
    Một Cog chuyên chứa các lệnh dùng để thử nghiệm và gỡ lỗi.
    """
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="testerror", help="[ADMIN] Cố tình gây ra lỗi để kiểm tra trình báo lỗi.")
    @is_bot_admin() # Bảo vệ lệnh, chỉ admin mới có thể dùng để tránh bị spam
    async def test_error(self, ctx):
        """
        Lệnh này sẽ luôn gây ra lỗi ZeroDivisionError (lỗi chia cho số 0).
        Mục đích là để kích hoạt hệ thống on_command_error và kiểm tra xem
        bot có gửi báo cáo lỗi chi tiết vào tin nhắn riêng cho admin không.
        """
        await ctx.send("⚙️ Đang thử nghiệm gây ra lỗi để kiểm tra hệ thống báo lỗi tự động...")

        # Dòng code này sẽ luôn luôn gây ra lỗi
        result = 1 / 0

async def setup(bot):
    await bot.add_cog(TestCommands(bot))